import random
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
import math
import torch
import torch.nn as nn
from collections import deque
import torch.nn.functional as F                 # 导入torch.nn.functional

d = {1_1: [], 1_2: [], 2_1: [], 2_2: []}
x =[]
# ############## 产生高需求，控制300步，一步三次需求 #############
for i  in range(300):
   if i<=25:
       x.append(i)
       a1 = random.uniform(0, 0.05)+(0.45/25)*i
       a2 = random.uniform(0, 0.05)+(0.45/25)*i
       a3 = random.uniform(0, 0.01)+(0.3/25)*i
       a4 = random.uniform(0, 0.01)+(0.3/25)*i
       d[1_1].append(a1)
       d[1_2].append(a2)
       d[2_1].append(a3)
       d[2_2].append(a4)
   elif 25<i<=50:
     x.append(i)
     a1 = random.uniform(0.45,0.5)
     a2 = random.uniform(0.45,0.5)
     a3 = random.uniform(0.3,0.35)
     a4 = random.uniform(0.3,0.35)
     d[1_1].append(a1)
     d[1_2].append(a2)
     d[2_1].append(a3)
     d[2_2].append(a4)
   elif 50 < i <= 75:
       x.append(i)
       a1 = random.uniform(1.35,1.35)+(-0.45/25)*i
       a2 = random.uniform(1.35,1.35)+(-0.45/25)*i
       a3 = random.uniform(0.9,0.9)+(-0.3/25)*i
       a4 = random.uniform(0.9,0.9)+(-0.3/25)*i
       d[1_1].append(a1)
       d[1_2].append(a2)
       d[2_1].append(a3)
       d[2_2].append(a4)
   else:
       x.append(i)
       d[1_1].append(0)
       d[1_2].append(0)
       d[2_1].append(0)
       d[2_2].append(0)
def fig_demand():
    plt.figure(figsize=(6,4))
    plt.rcParams['font.sans-serif']=['SimHei']
    plt.rcParams['axes.unicode_minus']=False
    plt.xlabel('time(2min)')
    plt.ylabel('demand(veh/sec)')
    plt.plot(x,d[1_1],label='d11',linewidth=0.5)
    plt.plot(x,d[1_2],label='d12',linewidth=0.5)
    plt.plot(x,d[2_1],label='d21',linewidth=0.5)
    plt.plot(x,d[2_2],label='d22',linewidth=0.5)
    plt.legend(loc='upper left')
    plt.title('高需求')
    plt.show()
    # print(d)
fig_demand()
#######################产生宏观控制参数U##################################
## MFD模型参数
N1 = 100
n11 = 60
n12 = 40
N2 = 160
n21 = 60
n22 = 100
N1_C = 2396
N2_C = 1338
N1_JAM = 4000
N2_JAM = 2500
l = [31.04, 21.415]
l1 =[3.1,2.9,3.0,3.3]
l2 =[1.9,2.1,2.0,1.3]
t_p = 5  # 预测步数
t_c = 240 # 控制时间 单位为秒
C = 120
t_s = 300  # 控制步数
G1 = -3E-08* pow(N1, 2) + 6E-04 *N1 + 0.0183
G2 = -6E-08*pow(N2, 2) + 8E-04 *N2  + 0.0399
m11 = (n11 / N1) * G1
m12 = (n12 / N1) * G1
m22 = (n22 / N2) * G2
m21 = (n21 / N1) * G2
#初始化
n_p={1_1:np.zeros(900),1_2:np.zeros(900),2_1:np.zeros(900),2_2:np.zeros(900)}#存放四状态
N_p={'区域1':np.zeros(900),'区域2':np.zeros(900)}#存放两区域
#d已经产生
G={'区域1':np.zeros(900),'区域2':np.zeros(900)}#存放两区域
m={1_1:np.zeros(900),1_2:np.zeros(900),2_1:np.zeros(900),2_2:np.zeros(900)}#存放实际转移流
vc = {'区域1': np.ones(900), '区域2': np.ones(900)}

#1.设置U值属于0-1,一个u的基因编码为7个数，一个个体包含40个u，前10个是u12，后10个u21

def jingdu(p,b):
    fanwei=b-p
    fenshu=1000
    for i in range(50):
        # print(2**i)
        w=2**i
        if w>(fanwei)*(fenshu):
           #i=10
            return i
        else:
            chrom_length=i
#2.设置种群大小即个体数量,有30个个体，每个个体由40个u组成，每个u由7个基因编码

def pop1(pop_size,u_num,chrom_length):
    pop=[]
    for i in range(pop_size):
        geti=[]
        for j in range(u_num):
            tem = []
            for k in range(chrom_length):
                s=random.randint(0,1)
                tem.append(s)
            # print(tem)
            geti.append(tem)
     # print(geti)
        pop.append(geti)
    # print(pop)
    return pop
def jiema(pop,pop_size,u_num,chrom_length):
    # pop=pop(getishuliang,u_num,jiyinchangdu)
    up=[]
    for i in range(pop_size):
        temp = []
        for j in range(u_num):
            t=0
            for k in range(chrom_length):
                t+=pop[i][j][k]*(math.pow(2,k))
            # print(t)
            u = t / (math.pow(2, chrom_length) - 1)
            temp.append(u)
            t = 0
        up.append(temp)
    return(up)
################################################
#3.根据守恒方程把u值放入，评价每个个体水平

def PingJiaGeTi(pop, chrom_length,curent_t):  ### 通过MPC获得预测步数内的区域内累计车辆数和完成流，以m/N的最大值作为适应度
    pingjiazhi = []
    u = jiema(pop,pop_size,u_num,chrom_length)#40个个体，每个个体含有20个值，前10个为U21，后10个为U12
    # print('len(u)',len(u))
    for i in range(len(u)):
        # print(u[i])
        f1 = 0
        f2 = 0
        for k in range(curent_t, curent_t + t_p):
            n_p[1_1][k + 1] = n_p[1_1][k] + C * (d[1_1][k]) + t_c * (u[i][k - curent_t + 5] * m[2_1][k] - m[1_1][k])  # 调用decodechrom(pop,chrom_length)后u的前20个值是1—2，后20个值是2—1
            # print('n_p[1_1][k + 1]',n_p[1_1][k + 1])
            n_p[1_2][k + 1] = n_p[1_2][k] + C * (d[1_2][k]) - t_c * (u[i][k - curent_t] * m[1_2][k])
            n_p[2_2][k + 1] = n_p[2_2][k] + C * (d[2_2][k]) + t_c * (u[i][k - curent_t] * m[1_2][k] - m[2_2][k])
            n_p[2_1][k + 1] = n_p[2_1][k] + C * (d[2_1][k]) - t_c * (u[i][k - curent_t + 5] * m[2_1][k])
            if n_p[1_1][k + 1] < 0:
                n_p[1_1][k + 1] = 0
            elif n_p[1_2][k + 1] < 0:
                n_p[1_2][k + 1] = 0
            elif n_p[2_2][k + 1] < 0:
                n_p[2_2][k + 1] = 0
            elif n_p[2_1][k + 1] < 0:
                n_p[2_1][k + 1] = 0

            N_p['区域1'][k + 1] = n_p[1_1][k + 1] + n_p[1_2][k + 1]
            N_p['区域2'][k + 1] = n_p[2_1][k + 1] + n_p[2_2][k + 1]
            # print('区域1车辆数', n_p[1_1][k + 1] + n_p[1_2][k + 1])
            # print('区域1车辆数', n_p[1_1][k + 1] + n_p[1_2][k + 1])

            # G['区域1'][k + 1] = -3E-09 * pow(N_p['区域1'][k + 1], 2) + 6E-05 * (N_p['区域1'][k + 1]) + 0.0183
            # G['区域2'][k + 1] = -6E-09 * pow(N_p['区域2'][k + 1], 2) + 8E-05 * (N_p['区域2'][k + 1]) + 0.0399
            G['区域1'][k + 1]  = -1E-07 * pow(N_p['区域1'][k + 1], 2) + 4E-04 * (N_p['区域1'][k + 1]) + 0.022
            G['区域2'][k + 1] = -2E-07 * pow(N_p['区域2'][k + 1], 2) + 5E-04 * (N_p['区域2'][k + 1]) + 0.0478

            # print(vc)
            if G['区域1'][k + 1] < 0:
                G['区域1'][k + 1] = 0
            if G['区域2'][k + 1] < 0:
                G['区域2'][k + 1] = 0
            if N_p['区域1'][k + 1] == 0 or G['区域1'][k + 1] == 0:
                m[1_1][k + 1] = 0
                m[1_2][k + 1] = 0
            else:
                m[1_1][k + 1] = (n_p[1_1][k + 1] / N_p['区域1'][k + 1]) * G['区域1'][k + 1]
                m[1_2][k + 1] = (n_p[1_2][k + 1] / N_p['区域1'][k + 1]) * G['区域1'][k + 1]
            if N_p['区域2'][k + 1] == 0 or G['区域2'][k + 1] == 0:
                m[2_1][k + 1] = 0
                m[2_2][k + 1] = 0
            else:
                m[2_1][k + 1] = (n_p[2_1][k + 1] / N_p['区域2'][k + 1]) * G['区域2'][k + 1]
                m[2_2][k + 1] = (n_p[2_2][k + 1] / N_p['区域2'][k + 1]) * G['区域2'][k + 1]

            if N_p['区域1'][k + 1] > 0:
                vc['区域1'][k + 1] = G['区域1'][k + 1] / (N_p['区域1'][k + 1] / (l[0] * 1000))
            else:
                vc['区域1'][k + 1] = 16.7  # 限速60
            if N_p['区域1'][k + 1] > 0:
                vc['区域2'][k + 1] = G['区域2'][k + 1] / (N_p['区域2'][k + 1] / (l[1] * 1000))
            else:
                vc['区域2'][k + 1] = 16.7  # 限速60

            if vc['区域1'][k + 1] < 0:
                vc['区域1'][k + 1] = 0
            # if vc['区域1'][k + 1] > 16.7:
            #     vc['区域1'][k + 1] = 16.7
            if vc['区域2'][k + 1] < 0:
                vc['区域2'][k + 1] = 0
            # if vc['区域1'][k + 1] > 16.7:
            #     vc['区域1'][k + 1] = 16.7

            f1 += (N_p['区域1'][k + 1]-N1_C)**2
                  # + (N_p['区域2'][k + 1]-N2_C)**2
            # f2 += m[2_2][k + 1] + m[1_1][k + 1]  # 由于需求设置使得G为0导致m为0，故f2为0，存在问题（可能是G的函数存在问题）

        f = 1/f1
        pingjiazhi.append(f)
    # print(obj_value)
    # print(len(obj_value))

    return pingjiazhi


def calfiValue(pingjiazhi):
    fit_value = []
    # c_min = 0
    # (m, obj_value) = calobjValue(pop, chrom_length)

    for i in range(len(pingjiazhi)):
        if (pingjiazhi[i] > 0 and pingjiazhi[i] < float('inf')):
            temp = pingjiazhi[i]
        else:
            temp = 0.0
        fit_value.append(temp)
    # print(fit_value)
    return fit_value


def sum(fit_value):
    total = 0
    for i in range(len(fit_value)):
        total += fit_value[i]
    return total


def cumsum(newfit):
    for i in range(len(newfit) - 2, -1, -1):
        t = 0
        j = 0
        while (j <= i):
            t += newfit[j]
            j += 1
        newfit[i] = t
        newfit[len(newfit) - 1] = 1

def selection(pop, fit_value):
    ms = []
    for i in range(len(pop)):
        ms.append(random.random())
    ms.sort()
    # print(ms)

    newfit=[]
    totalfit=sum(fit_value)
    for i in range(len(fit_value)):
        newfit.append(fit_value[i] / totalfit)
    # print(newfit)
    cumsum(newfit)

    fitin = 0
    newin = 0
    newpop = pop
    while newin < len(pop) and fitin < len(pop):
        if (ms[newin] < newfit[fitin]):
            newpop[newin] = pop[fitin]
            newin += 1
        else:
            fitin += 1
    pop = newpop
    return pop


def crossover(pop, pc):
    for i in range(len(pop)-1):
        for j in range (u_num):
         if (random.random() < pc):
            cpoint = random.randint(0, jingdu(0,1))
            temp1 = []
            temp2 = []
            temp1.extend(pop[i][j][0:cpoint])
            temp1.extend(pop[i + 1][j][cpoint:len(pop[i][j])])
            temp2.extend(pop[i + 1][j][0:cpoint])
            temp2.extend(pop[i + 1][j][cpoint:len(pop[i][j])])
            pop[i][j] = temp1
            pop[i + 1][j] = temp2
    return pop


def mutation(pop, pm):
    for i in range(len(pop)):
        for j in range(u_num):
         if (random.random() < pm):
            mpoint = random.randint(0, jingdu(0,1) - 1)
            if (pop[i][j][mpoint] == 1):
                pop[i][j][mpoint] = 0
            else:
                pop[i][j][mpoint] = 1
    return pop
    # 找出最优值
def best(pop, fit_value):
        px = len(pop)
        best_individual = []
        best_fit = fit_value[0]
        for i in range(px):
            if fit_value[i] > best_fit:
                # print(best_fit)
                # print(fit_value[i])
                best_fit = fit_value[i]
                best_individual = pop[i]
            else:
                best_individual = pop[0]

        # print(best_fit)


        return best_individual, best_fit

 # 将二进制转化为十进制
def b2d(best_individual):
            length = len(best_individual)
            u_best = []
            t = 0
            for i in range(int(2 * t_p)):
                for k in range(jingdu(0,1)):
                    t += best_individual[i][k] * (math.pow(2, k))
                u = t / (math.pow(2, chrom_length) - 1)
                u_best.append(u)
                t = 0
            a = [u_best[0], u_best[5]]
            return a  # u_best[0]是在t时刻u12的最优值，u_best[19]是在t时刻u21的最优值

def result():
    pop=pop1
#这个数字代表种群繁衍代数
    for i in range(1):
        fit = PingJiaGeTi(pop, chrom_length)  # 从0时刻开始，计算30套方案的适应函数#3.根据守恒方程把u值放入，评价每个个体水平PingJiaGeTi(s,up,pop_size,u_num)
        fitvalue = calfiValue(fit)  # 30个适应值
        # print(fitvalue)
        # best_individual, best_fit = best(pop, fitvalue)
        # u3 = b2d(best_individual)
        # print(u3)
        # print()
        pop = selection(pop, fitvalue)  # 30套方案，种群选择
        pop = crossover(pop, pc)
        pop = mutation(pop, pm)
    fit = PingJiaGeTi(pop, chrom_length)  # 从0时刻开始，计算30套方案的适应函数#3.根据守恒方程把u值放入，评价每个个体水平PingJiaGeTi(s,up,pop_size,u_num)
    fitvalue = calfiValue(fit)  # 30个适应值
    # print(fitvalue)
    best_individual, best_fit = best(pop, fitvalue)
    u2 = b2d(best_individual)
    for i in range(2):
        if u2[i] <= 0.1:
            u2[i] = 0.1
    for i in range(2):
        if u2[i] >1:
            u2[i] = 1
    U21.append(u2[0])
    U12.append(u2[1])


    return U12,U21
######################微观层面信号方案优化######################################
#超参数
BATCH_SIZE = 32                                 # 样本数量
LR = 0.02                                       # 学习率
EPSILON = 0.8                                   # greedy policy
GAMMA = 0.9                                     # reward discount
TARGET_REPLACE_ITER = 100                       # 目标网络更新频率
MEMORY_CAPACITY = 1000                          # 记忆库容量
# 定义环境

Action={0:[10,50,30,30],1:[15,45,30,30],2:[20,40,30,30],3:[25,35,30,30],4:[30,30,30,30],5:[35,25,30,30],6:[40,20,30,30],7:[45,15,30,30],
        8:[50,10,25,35],9:[30,30,25,35],10:[30,30,20,40],11:[30,30,15,45],12:[30,30,10,50],13:[30,30,35,25],14:[30,30,40,20],15:[30,30,45,15],
        16:[30,30,50,10],17:[30,20,40,30]}
N_ACTIONS = len(Action)                                 # 动作个数 (6个)
N_STATES = 18
# 定义Net类 (定义网络)
class Net(nn.Module):
    def __init__(self):                                                         # 定义Net的一系列属性
        # nn.Module的子类函数必须在构造函数中执行父类的构造函数
        super(Net, self).__init__()                                             # 等价与nn.Module.__init__()

        self.fc1 = nn.Linear(N_STATES, 50)                                      # 设置第一个全连接层(输入层到隐藏层): 状态数个神经元到50个神经元
        self.fc1.weight.data.normal_(0, 0.1)                                    # 权重初始化 (均值为0，方差为0.1的正态分布)
        self.out = nn.Linear(50, N_ACTIONS)                                     # 设置第二个全连接层(隐藏层到输出层): 50个神经元到动作数个神经元
        self.out.weight.data.normal_(0, 0.1)                                    # 权重初始化 (均值为0，方差为0.1的正态分布)

    def forward(self, x):                                                       # 定义forward函数 (x为状态)
        # print(x.shape)
        x = F.relu(self.fc1(x))                                                 # 连接输入层到隐藏层，且使用激励函数ReLU来处理经过隐藏层后的值
        actions_value = self.out(x)                                             # 连接隐藏层到输出层，获得最终的输出值 (即动作值)
        return actions_value                                                    # 返回动作值


# 定义DQN类 (定义两个网络)
class DQN(object):
    def __init__(self):                                                         # 定义DQN的一系列属性
        self.eval_net, self.target_net = Net(), Net()                           # 利用Net创建两个神经网络: 评估网络和目标网络
        self.learn_step_counter = 0                                             # for target updating
        self.memory_counter = 0                                                 # for storing memory
        self.memory = np.zeros((MEMORY_CAPACITY, N_STATES * 2 + 2))             # 初始化记忆库，一行代表一个transition
        self.optimizer = torch.optim.Adam(self.eval_net.parameters(), lr=LR)    # 使用Adam优化器 (输入为评估网络的参数和学习率)
        self.loss_func = nn.MSELoss()                                           # 使用均方损失函数 (loss(xi, yi)=(xi-yi)^2)

    def choose_action(self, x):                                                 # 定义动作选择函数 (x为状态)
        x = torch.unsqueeze(torch.FloatTensor(x), 0)                            # 将x转换成32-bit floating point形式，并在dim=0增加维数为1的维度
        if np.random.uniform() < EPSILON:                                       # 生成一个在[0, 1)内的随机数，如果小于EPSILON，选择最优动作
            actions_value = self.eval_net.forward(x)                            # 通过对评估网络输入状态x，前向传播获得动作值
            action = torch.max(actions_value, 1)[1].data.numpy()                # 输出每一行最大值的索引，并转化为numpy ndarray形式
#           values,indices = torch.max(input, dim)
            action_index = action[0]                                                  # 输出action的第一个数
        else:                                                                   # 随机选择动作
            action_index = np.random.randint(0, 9)                            # 这里action随机等于0或1 (N_ACTIONS = 2)

        return action_index                                                           # 返回选择的动作 (0或1)

    def store_transition(self, s, a, r, s_):                                    # 定义记忆存储函数 (这里输入为一个transition)
        transition = np.hstack((s, [a, r], s_))                                 # 在水平方向上拼接数组
        # 如果记忆库满了，便覆盖旧的数据
        # print('self.memory.shape',self.memory.shape)
        # print('transition', transition)
        index = self.memory_counter % MEMORY_CAPACITY                           # 获取transition要置入的行数
        self.memory[index, :] = transition                                      # 置入transition
        self.memory_counter += 1                                                # memory_counter自加1


    def learn(self):  # 定义学习函数(记忆库已满后便开始学习)
        # 目标网络参数更新
        if self.learn_step_counter % TARGET_REPLACE_ITER == 0:  # 一开始触发，然后每100步触发
            self.target_net.load_state_dict(self.eval_net.state_dict())  # 将评估网络的参数赋给目标网络
        self.learn_step_counter += 1  # 学习步数自加1

        # 抽取记忆库中的批数据
        sample_index = np.random.choice(MEMORY_CAPACITY, BATCH_SIZE)  # 在[0, 2000)内随机抽取32个数，可能会重复
        b_memory = self.memory[sample_index, :]  # 抽取32个索引对应的32个transition，存入b_memory
        b_s = torch.FloatTensor(b_memory[:, :N_STATES])
        # 将32个s抽出，转为32-bit floating point形式，并存储到b_s中，b_s为32行4列
        b_a = torch.LongTensor(b_memory[:, N_STATES:N_STATES + 1].astype(int))
        # 将32个a抽出，转为64-bit integer (signed)形式，并存储到b_a中 (之所以为LongTensor类型，是为了方便后面torch.gather的使用)，b_a为32行1列
        b_r = torch.FloatTensor(b_memory[:, N_STATES + 1:N_STATES + 2])
        # 将32个r抽出，转为32-bit floating point形式，并存储到b_s中，b_r为32行1列
        b_s_ = torch.FloatTensor(b_memory[:, -N_STATES:])
        # 将32个s_抽出，转为32-bit floating point形式，并存储到b_s中，b_s_为32行4列

        # 获取32个transition的评估值和目标值，并利用损失函数和优化器进行评估网络参数更新
        q_eval = self.eval_net(b_s).gather(1, b_a)
        # eval_net(b_s)通过评估网络输出32行每个b_s对应的一系列动作值，然后.gather(1, b_a)代表对每行对应索引b_a的Q值提取进行聚合
        q_next = self.target_net(b_s_).detach()
        # q_next不进行反向传递误差，所以detach；q_next表示通过目标网络输出32行每个b_s_对应的一系列动作值
        q_target = b_r + GAMMA * q_next.max(1)[0].view(BATCH_SIZE, 1)
        # q_next.max(1)[0]表示只返回每一行的最大值，不返回索引(长度为32的一维张量)；.view()表示把前面所得到的一维张量变成(BATCH_SIZE, 1)的形状；最终通过公式得到目标值
        loss = self.loss_func(q_eval, q_target)
        # 输入32个评估值和32个目标值，使用均方损失函数
        self.optimizer.zero_grad()                                      # 清空上一步的残余更新参数值
        loss.backward()                                                 # 误差反向传播, 计算参数更新值
        self.optimizer.step()                                           # 更新评估网络的所有参数


dqn = DQN()


class env(object):
    def __init__(self):
        self.l1 = [3.1, 2.9, 3.0, 3.3]  # 四个路口的长度
        self.l2 = [1.9, 2.1, 2.0, 1.3]
        self.lh = [1.2, 1.35, 1.5]  # 交叉口之间的距离，单位 km
        self.alpha = [0.3, 0.5, 0.2]  # 0.3左转，0.5直行，0.2右转
        self.lv = 4  # 私家车长度 ， 单位m
        self.n_m = {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)),
            '出口4': np.zeros((900, 4))}  # 交叉口进口等待的社会车与公交车之和
        #####初始化#####
        self.s_start=[]
        for t in range(1):
            for h in range(4):
                for i in self.n_m:
                       self.n_m[i][t][h]=5
        for h in range(4):
            for i in self.n_m:
                self.s_start.append(self.n_m[i][0][h])
        self.s_start.append(20)
        self.s_start.append(20)
        self.td_c  = {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)),
            '出口4': np.zeros((900, 4))}  # 私家车时延
        self.i_mc= {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)),
           '出口4': np.zeros((900, 4))}  # 交叉口进口的社会车与公交车之和
        self.sta_flow  = 0.4  # 饱和流
        self.l_m  = {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)),
           '出口4': np.zeros((900, 4))}  # 四个进口道的左转车辆数
        self.s_m  = {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)), '出口4': np.zeros((900, 4))}
        self.r_m = {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)),
                    '出口4': np.zeros((900, 4))}
        self.trans_l_m = {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)),
                    '出口4': np.zeros((900, 4))}  # 四个进口道的左转车辆数
        self.trans_s_m = {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)),
                    '出口4': np.zeros((900, 4))}
        self.trans_r_m = {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)),
                    '出口4': np.zeros((900, 4))}

        self.remain_l_m = {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)),
                          '出口4': np.zeros((900, 4))}  # 四个进口道的左转车辆数
        self.remain_s_m = {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)),
                          '出口4': np.zeros((900, 4))}
        self.remain_r_m = {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)),
                          '出口4': np.zeros((900, 4))}
        self.actal_o_m = {'1-2': np.zeros((900, 4)), '2-1': np.zeros((900, 4))}
        self.ZhuanYi1to2=[]
        self.ZhuanYi2to1 = []

        self.o_m  =  {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)),
           '出口4': np.zeros((900, 4))}  # 交叉口出口的社会车与公交车之和
        self.remain_m = {'出口1': np.zeros((900, 4)), '出口2': np.zeros((900, 4)), '出口3': np.zeros((900, 4)),
                    '出口4': np.zeros((900, 4))}  # 交叉口出口的社会车与公交车之和
        self.qc1 = 0.05
        self.qc2 = 0.05
        self.C = 120
        self.vc = {'区域1': np.ones(900), '区域2': np.ones(900)}


    def Doaction(self, t,a):
        action = Action[a]
        # step1:获取路口h各进口道的等待车辆数
        if t > 0:
            for h in range(4):
                for i in self.n_m:
                    self.n_m[i][t][h] = self.n_m[i][t - 1][h] + self.i_mc[i][t - 1][h] - self.o_m[i][t - 1][h]  # 四个进口的车辆数
                    if self.n_m[i][t][h] <= 0:
                           self.n_m[i][t][h]=0
                    # print('self.n_m[i][t][h]', self.n_m[i][t][h])
        else:
            pass
        for h in range(4):
            for i in self.n_m:
                print('当前时刻为%s,road num is %s,进口道编号是 %s,等待车辆数是%s' %(t,h,i,self.n_m[i][t][h]))

        for h in range(4):
            # step2:计算当前时刻各进口道时延
            self.vc['区域1'][0]=7
            self.vc['区域2'][0]=8
            self.td_c['出口1'][t][h] = math.ceil(((self.l1[0] * 1000 * 3 - self.n_m['出口1'][t][h] * self.lv) / (3 * self.vc['区域1'][0] * self.C)))  # 为什么这里的社会车速度不是等于实时的区域平均速度
            self.td_c['出口3'][t][h] = math.ceil(((self.l1[3] * 1000 * 3 - self.n_m['出口3'][t][h] * self.lv) / (3 * self.vc['区域2'][0] * self.C)))  # 为什么这里的社会车速度不是等于实时的区域平均速度
            if h == 0:
                  self.td_c['出口2'][t][h] = 0  # 非控制区域3的需求，直接通过到达率计算
            else:
                  self.td_c['出口2'][t][h] =math.ceil(((self.lh[h - 1] * 1000 * 3 - self.n_m['出口2'][t][h] * self.lv) / (3 * self.vc['区域1'][0] * self.C)))
            if h == 3:
                  self.td_c['出口4'][t][h] = 0  # 非控制区域4的需求，直接通过到达率计算
            else:
                  self.td_c['出口4'][t][h] =math.ceil(((self.lh[h] * 1000 * 3 - self.n_m['出口4'][t][h] * self.lv) / (3 * self.vc['区域2'][0] * self.C)))
            cc1 = int(t - abs(self.td_c['出口1'][t][h]))
            cc2 = int(t - abs(self.td_c['出口3'][t][h]))
            cc3 = int(t - abs(self.td_c['出口2'][t][h]))
            cc4 = int(t - abs(self.td_c['出口4'][t][h]))
              # step3:获得当前时刻各进口道增加的车辆需求
              ### 四个交叉口中，进口1和进口3的上游不存在交叉口，所以进入该交叉口的车辆数通过需求获得，进口2和进口4可能存在交叉口也可能不存在交叉口，所以进行分类计算
            if cc1 >= 0 and cc2 >= 0 and cc3 >= 0 and cc4 >= 0:
                  self.i_mc['出口1'][t][h] = self.C * (0.25 * d[1_2][cc1])  # 社会车通过logit模型获得分流率r1，获得进入各个路口的车辆数
                  self.i_mc['出口3'][t][h] = self.C * (0.25 * d[2_1][cc2])
                  if h == 0:
                      self.i_mc['出口2'][t][h] = self.C * self.qc1  # 非控制区域3的需求，直接通过到达率计算
                  else:
                      self.i_mc['出口2'][t][h] = self.o_m['出口1'][cc3][h - 1] * self.alpha[2] + self.o_m['出口2'][cc3][h - 1] * \
                                               self.alpha[1] + self.o_m['出口3'][cc3][h - 1] * self.alpha[0]  # 存疑 ，
                  if h == 3:
                      self.i_mc['出口4'][t][h] = self.C * self.qc2  # 非控制区域4的需求，直接通过到达率计算
                  else:
                      self.i_mc['出口4'][t][h] = self.o_m['出口1'][cc4][h + 1] * self.alpha[0] + self.o_m['出口3'][cc4][h + 1] * \
                                               self.alpha[2] + self.o_m['出口4'][cc4][h + 1] * self.alpha[1]
            else:
                  self.i_mc['出口1'][t][h] = 10
                  self.i_mc['出口3'][t][h] = 10
                  if h == 0:
                      self.i_mc['出口2'][t][h] = 10
                  else:
                      self.i_mc['出口2'][t][h] = 10
                  if h == 3:
                      self.i_mc['出口4'][t][h] = 10
                  else:
                      self.i_mc['出口4'][t][h] = 10

              #step4:各进口道的左直右车辆数


            self.l_m['出口1'][t][h] = self.n_m['出口1'][t][h] * self.alpha[0]
            self.l_m['出口2'][t][h] = self.n_m['出口2'][t][h] * self.alpha[0]
            self.l_m['出口3'][t][h] = self.n_m['出口3'][t][h] * self.alpha[0]
            self.l_m['出口4'][t][h] = self.n_m['出口4'][t][h] * self.alpha[0]
            self.s_m['出口1'][t][h] = self.n_m['出口1'][t][h] * self.alpha[1]
            self.s_m['出口2'][t][h] = self.n_m['出口2'][t][h] * self.alpha[1]
            self.s_m['出口3'][t][h] = self.n_m['出口3'][t][h] * self.alpha[1]
            self.s_m['出口4'][t][h] = self.n_m['出口4'][t][h] * self.alpha[1]
            self.r_m['出口1'][t][h] = self.n_m['出口1'][t][h] * self.alpha[2]
            self.r_m['出口2'][t][h] = self.n_m['出口2'][t][h] * self.alpha[2]
            self.r_m['出口3'][t][h] = self.n_m['出口3'][t][h] * self.alpha[2]
            self.r_m['出口4'][t][h] = self.n_m['出口4'][t][h] * self.alpha[2]
            # print('进口1左转', self.l_m['出口1'][t][h])
            # print('进口2左转',self.l_m['出口2'][t][h])
            # print('进口3左转',self.l_m['出口3'][t][h])
            # print('进口4左转',self.l_m['出口4'][t][h])
            # print('进口1直行', self.s_m['出口1'][t][h])
            # print('进口2直行',self.s_m['出口2'][t][h])
            # print('进口3直行',self.s_m['出口3'][t][h])
            # print('进口4直行',self.s_m['出口4'][t][h])
            # print('进口1右转', self.r_m['出口1'][t][h])
            # print('进口2右转',self.r_m['出口2'][t][h])
            # print('进口3右转',self.r_m['出口3'][t][h])
            # print('进口4右转',self.r_m['出口4'][t][h])
               #step5：相位绿灯时间转移
              #相位1
            print('进口4等待左转车辆数是%s,进口1等待直行的车辆数是%s,此次最大通过数为%s'% (self.l_m['出口4'][t][h],self.s_m['出口1'][t][h],self.sta_flow*action[0]))
            if self.l_m['出口4'][t][h]+self.s_m['出口1'][t][h]<self.sta_flow*action[0]:
                  self.trans_l_m['出口4'][t][h] = self.l_m['出口4'][t][h]
                  self.trans_s_m['出口1'][t][h] = self.s_m['出口1'][t][h]
                  self.trans_r_m['出口2'][t][h] = self.r_m['出口2'][t][h]
            else:
                  self.trans_l_m['出口4'][t][h] = (self.l_m['出口4'][t][h]/(self.l_m['出口4'][t][h]+self.s_m['出口1'][t][h]))*self.sta_flow*action[0]
                  self.trans_s_m['出口1'][t][h] = (self.l_m['出口1'][t][h]/(self.l_m['出口4'][t][h]+self.s_m['出口1'][t][h]))*self.sta_flow*action[0]
                  self.trans_r_m['出口2'][t][h] = self.r_m['出口2'][t][h]
              #相位2
            if self.l_m['出口2'][t][h]+self.s_m['出口3'][t][h]<self.sta_flow*action[1]:
                  self.trans_l_m['出口2'][t][h] = self.l_m['出口2'][t][h]
                  self.trans_s_m['出口3'][t][h] = self.s_m['出口3'][t][h]
                  self.trans_r_m['出口4'][t][h] = self.r_m['出口4'][t][h]
            else:
                  self.trans_l_m['出口2'][t][h] = (self.l_m['出口2'][t][h]/(self.l_m['出口2'][t][h]+self.s_m['出口3'][t][h]))*self.sta_flow*action[1]
                  self.trans_s_m['出口3'][t][h] = (self.l_m['出口3'][t][h]/(self.l_m['出口2'][t][h]+self.s_m['出口3'][t][h]))*self.sta_flow*action[1]
                  self.trans_r_m['出口2'][t][h] = self.r_m['出口2'][t][h]
              # 相位3
            if self.l_m['出口1'][t][h] + self.s_m['出口2'][t][h] < self.sta_flow * action[2]:
                  self.trans_l_m['出口1'][t][h] = self.l_m['出口1'][t][h]
                  self.trans_s_m['出口2'][t][h] = self.s_m['出口2'][t][h]
                  self.trans_r_m['出口3'][t][h] = self.r_m['出口3'][t][h]
            else:
                  self.trans_l_m['出口1'][t][h] = (self.l_m['出口1'][t][h]/(self.l_m['出口1'][t][h] + self.s_m['出口2'][t][h])) * self.sta_flow * action[2]
                  self.trans_s_m['出口2'][t][h] = (self.s_m['出口2'][t][h]/(self.l_m['出口1'][t][h] + self.s_m['出口2'][t][h])) * self.sta_flow * action[2]
                  self.trans_r_m['出口3'][t][h] = self.r_m['出口3'][t][h]
              # 相位4
            if self.l_m['出口3'][t][h] + self.s_m['出口4'][t][h] < self.sta_flow * action[3]:
                  self.trans_l_m['出口3'][t][h] = self.l_m['出口3'][t][h]
                  self.trans_s_m['出口4'][t][h] = self.s_m['出口4'][t][h]
                  self.trans_r_m['出口1'][t][h] = self.r_m['出口1'][t][h]
            else:
                  self.trans_l_m['出口3'][t][h] = (self.l_m['出口3'][t][h] / (self.l_m['出口3'][t][h] + self.s_m['出口4'][t][h]) )* self.sta_flow * action[3]
                  self.trans_s_m['出口4'][t][h] = (self.s_m['出口4'][t][h]/ (self.l_m['出口3'][t][h] + self.s_m['出口4'][t][h])) * self.sta_flow * action[3]
                  self.trans_r_m['出口1'][t][h] = self.r_m['出口1'][t][h]

            self.remain_s_m['出口1'][t][h] = self.s_m['出口1'][t][h] - self.trans_s_m['出口1'][t][h]
            self.remain_l_m['出口1'][t][h] = self.l_m['出口1'][t][h] - self.trans_l_m['出口1'][t][h]
            self.remain_r_m['出口1'][t][h] = 0

            self.remain_s_m['出口2'][t][h] = self.s_m['出口2'][t][h] - self.trans_s_m['出口2'][t][h]
            self.remain_l_m['出口2'][t][h] = self.l_m['出口2'][t][h] - self.trans_l_m['出口2'][t][h]
            self.remain_r_m['出口2'][t][h] = 0

            self.remain_s_m['出口3'][t][h] = self.s_m['出口3'][t][h] - self.trans_s_m['出口3'][t][h]
            self.remain_l_m['出口3'][t][h] = self.l_m['出口3'][t][h] - self.trans_l_m['出口3'][t][h]
            self.remain_r_m['出口3'][t][h] = 0

            self.remain_s_m['出口4'][t][h] = self.s_m['出口4'][t][h] - self.trans_s_m['出口4'][t][h]
            self.remain_l_m['出口4'][t][h] = self.l_m['出口4'][t][h] - self.trans_l_m['出口4'][t][h]
            self.remain_r_m['出口4'][t][h] = 0

            self.o_m['出口1'][t][h] = self.trans_s_m['出口1'][t][h]+self.trans_r_m['出口1'][t][h]+self.trans_l_m['出口1'][t][h]
            self.o_m['出口2'][t][h] = self.trans_s_m['出口2'][t][h]+self.trans_r_m['出口2'][t][h]+self.trans_l_m['出口2'][t][h]
            self.o_m['出口3'][t][h] = self.trans_s_m['出口3'][t][h]+self.trans_r_m['出口3'][t][h]+self.trans_l_m['出口3'][t][h]
            self.o_m['出口4'][t][h] = self.trans_s_m['出口4'][t][h]+self.trans_r_m['出口4'][t][h]+self.trans_l_m['出口4'][t][h]

            self.remain_m['出口1'][t][h] = self.remain_s_m['出口1'][t][h] + self.remain_r_m['出口1'][t][h] + self.remain_l_m['出口1'][t][h]
            self.remain_m['出口2'][t][h] = self.remain_s_m['出口2'][t][h] + self.remain_r_m['出口2'][t][h] + self.remain_l_m['出口2'][t][h]
            self.remain_m['出口3'][t][h] = self.remain_s_m['出口3'][t][h] + self.remain_r_m['出口3'][t][h] +  self.remain_l_m['出口3'][t][h]
            self.remain_m['出口4'][t][h] = self.remain_s_m['出口4'][t][h] + self.remain_r_m['出口4'][t][h] + self.remain_l_m['出口4'][t][h]



            self.actal_o_m['1-2'][t][h]=self.trans_l_m['出口4'][t][h]+self.trans_s_m['出口1'][t][h]+self.trans_r_m['出口2'][t][h]
            self.actal_o_m['2-1'][t][h] = self.trans_l_m['出口2'][t][h] + self.trans_s_m['出口3'][t][h] + self.trans_r_m['出口4'][t][h]
              # print('1-2转移流',t,h,self.actal_o_m['1-2'][t][h])
        # print('t时刻0路口区域1到区域2的流量')
        # print(self.trans_l_m['出口4'][t][0])
        # print(self.trans_s_m['出口1'][t][0])
        # print(self.trans_r_m['出口2'][t][0])
        # print('t时刻1路口区域1到区域2的流量')
        # print(self.trans_l_m['出口4'][t][1])
        # print(self.trans_s_m['出口1'][t][1])
        # print(self.trans_r_m['出口2'][t][1])
        # print('t时刻2路口区域2到区域2的流量')
        # print(self.trans_l_m['出口4'][t][2])
        # print(self.trans_s_m['出口1'][t][2])
        # print(self.trans_r_m['出口2'][t][2])
        # print('t时刻3路口区域1到区域2的流量')
        # print(self.trans_l_m['出口4'][t][3])
        # print(self.trans_s_m['出口1'][t][3])
        # print(self.trans_r_m['出口2'][t][3])
        #
        # print('t时刻各路口区域1到区域2的流量')
        # print(self.actal_o_m['1-2'][t][0])
        # print(self.actal_o_m['1-2'][t][1])
        # print(self.actal_o_m['1-2'][t][2])
        # print(self.actal_o_m['1-2'][t][2])
        # print('M2-1的流量组成情况')
        # print(self.actal_o_m['2-1'][t][0])
        # print(self.actal_o_m['2-1'][t][1])
        # print(self.actal_o_m['2-1'][t][2])
        # print(self.actal_o_m['2-1'][t][2])
        a12=self.actal_o_m['1-2'][t][0]+self.actal_o_m['1-2'][t][1]+self.actal_o_m['1-2'][t][2]+self.actal_o_m['1-2'][t][3]
        self.ZhuanYi1to2.append(a12)
        b21= self.actal_o_m['2-1'][t][0] + self.actal_o_m['2-1'][t][1] + self.actal_o_m['2-1'][t][2] + self.actal_o_m['2-1'][t][3]

        self.ZhuanYi2to1.append(b21)
       # print('1-2转移流', t, h, self.ZhuanYi1to2)
       # print('2-1转移流', t, h, self.ZhuanYi2to1)
        reward = -(abs(M1_2[t] - a12) + abs(M2_1[t] - b21))
        print('区域1——2预期转移值is%s,区域1——2实际转移值is%s,差值是 %s' % (round(M1_2[t], 2),round(a12, 2),round(abs(M1_2[t] - a12), 2)))
        print('区域2——1预期转移值is%s,区域2——1实际转移值is%s,差值是 %s' % (round(M2_1[t], 2), round(b21, 2), round(abs(M2_1[t] - b21), 2)))
        print('两个区域的转移差值是%s'%(-reward))
        state = []
        for h in range(4):
          # print(h)
          for i in self.n_m:
               # print(i)
               self.n_m[i][t+1][h] = self.n_m[i][t][h] + self.i_mc[i][t][h] - self.o_m[i][t][h]
               state.append(self.n_m[i][t][h])
               # print(state)
               # print(len(state))
        state.append(M1_2[t+1])
        state.append(M2_1[t+1])
           # print(reward)
        if t==control_step:
               done=True
        else:
               done = False
        return  reward,state,done
def picture(x,y1,y2):
    plt.figure(figsize=(6,4))
    plt.rcParams['font.sans-serif']=['SimHei']
    plt.rcParams['axes.unicode_minus']=False
    plt.xlabel('time(5min)')
    plt.ylabel('U')
    plt.plot(x,y1,label='u21',linewidth=1)
    plt.plot(x,y2,label='u12',linewidth=0.5)
    plt.legend(loc='upper left')
    plt.title('边界控制')
    plt.grid(True)
    plt.show()



if __name__ == "__main__":
    n_p[1_1][0] = 50
n_p[1_2][0] = 50
n_p[2_1][0] = 50
n_p[2_2][0] = 40
N_p['区域1'][0] = 100
N_p['区域2'][0] = 90
pc = 0.8
pm = 0.05
chrom_length=jingdu(0,1)
print(chrom_length)
pop_size=40  #40个个体
u_num=10  #每个个体有20个值
t_s=300 #控制步数为300步
U21=[1]
U12=[1]
s=1
x=[1]
M1_2=[20]
M2_1=[20]

for j in range(100):
    if_stop = False  # 是否停止循环，差值小于0.5时停止
    while not if_stop:
        curent_t=j
        pop = pop1(pop_size, u_num, chrom_length)  # 产生初始种群
        for i in range(30):
            fit = PingJiaGeTi(pop, chrom_length,curent_t)  # 从0时刻开始，计算40套方案的适应函数#3.根据守恒方程把u值放入，评价每个个体水平PingJiaGeTi(s,up,pop_size,u_num)
            fitvalue = calfiValue(fit)  # 40个适应值
            pop = selection(pop, fitvalue)  # 30套方案，种群选择
            pop = crossover(pop, pc)
            pop = mutation(pop, pm)
        fit = PingJiaGeTi(pop, chrom_length,curent_t)  # 从0时刻开始，计算30套方案的适应函数#3.根据守恒方程把u值放入，评价每个个体水平PingJiaGeTi(s,up,pop_size,u_num)
        fitvalue = calfiValue(fit)  # 40个适应值
        best_individual, best_fit = best(pop, fitvalue)
        u2 = b2d(best_individual)
        for i in range(2):
            if u2[i] <= 0.1:
                u2[i] = 0.1
        for i in range(2):
            if u2[i] >1:
                u2[i] = 1
        off_u21 = abs(u2[0]-U21[-1])
        if off_u21<=0.3 and int(n_p[1_1][curent_t] + n_p[1_2][curent_t])<4000:
          U21.append(u2[0])
          U12.append(u2[1])
          print('区域1车辆数', int(n_p[1_1][curent_t] + n_p[1_2][curent_t]))
          print('区域2车辆数', int(n_p[2_1][curent_t] + n_p[2_2][curent_t]))
          com21 = (U21[0] * m[2_1][curent_t]) * t_c
          com12 = (U12[1] *m[1_2][curent_t]) * t_c
          M1_2.append(int(com21))
          M2_1.append(int(com12))
          s=s+1
          x.append(s)
          if_stop = True
        else:
            pass
print(U21)
print(U12)
print(M1_2)
print(M2_1)
# #
# #
picture(x,y1=U21,y2=U12)
picture(x,y1=M2_1,y2=M1_2)


control_step=99
def DQN():
    Episode=[]
    Episode_reward=[]
    for i in range(200):                                                    # 400个episode循环
        print('<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Episode: %s' % i)
        t=0                                                     # 重置环境
        episode_reward_sum = 0                                              # 初始化该循环对应的episode的总奖励
        huanjing = env()
        s =huanjing.s_start
        while True:                                                         # 开始一个episode (每一个循环代表一步)                                  # 显示实验动画
             a= dqn.choose_action(s)
             # print("t is ", t)# 输入该步对应的状态s，选择动作
             print('a is ',a)
             r,s_,done=env.Doaction(huanjing,t,a)
             t+=1
             dqn.store_transition(s, a, r, s_)                 # 存储样本
             # print('奖赏值',r)

             episode_reward_sum += -r                           # 逐步加上一个episode内每个step的reward
             s = s_                                                # 更新状态
             if dqn.memory_counter > MEMORY_CAPACITY:              # 如果累计的transition数量超过了记忆库的固定容量2000
    #             # 开始学习 (抽取记忆，即32个transition，并对评估网络参数进行更新，并在开始学习后每隔100次将评估网络的参数赋给目标网络)
                 dqn.learn()
             if done:  # 如果done为True
    #             # round()方法返回episode_reward_sum的小数点四舍五入到2个数字
                 print('episode%s---reward_sum: %s' % (i, round(episode_reward_sum, 2)))
                 Episode.append(i)
                 Q=round(episode_reward_sum, 2)
                 # if Q>25000:
                 #     Q=10000
                 # else:
                 #     pass
                 Episode_reward.append(Q)
                 break
    print(Episode)
    print(Episode_reward)
    plt.figure(figsize=(6, 4))
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    plt.xlabel('训练次数(次）')
    plt.ylabel('差距')
    plt.plot(Episode, Episode_reward, label='差距值', linewidth=1)
    # plt.plot(x, y2, label='u12', linewidth=0.5)
    plt.legend(loc='upper left')
    plt.title('迭代结果')
    plt.grid(True)
    plt.show()
    # plt.figure(figsize=(6,4))
    # plt.rcParams['font.sans-serif']=['SimHei']
    # plt.rcParams['axes.unicode_minus']=False
    # plt.xlabel('Episode')
    # plt.ylabel('Episode_reward')
    # colors1 = '#000000' #点的颜色
    # area = np.pi * 1**2  # 点面积
    # plt.scatter(Episode, Episode_reward, s=area, c=colors1, alpha=0.4, label='差距值')
    # # plt.plot(Episode,Episode_reward,label='reward',linewidth=1)
    # plt.legend(loc='upper left')
    # plt.title('迭代结果')
    # plt.grid(True)
    # plt.show()
DQN()