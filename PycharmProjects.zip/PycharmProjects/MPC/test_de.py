import numpy as np
import random
import matplotlib.pyplot as plt
dc = {1_1: [], 1_2: [], 2_1: [], 2_2: []}
db = {1_1: [], 1_2: [], 2_1: [], 2_2: []}
d = {1_1: [], 1_2: [], 2_1: [], 2_2: []}
x =[]

############# 产生低需求，控制300步，一步三次需求 #############
# for i  in range(1700):
#   if i<=45:
#       a1 = random.uniform(0, 0.1)+(0.35/45)*i
#       a2 = random.uniform(0, 0.1)+(0.25/45)*i
#       a3 = random.uniform(0, 0.1)+(0.35/45)*i
#       a4 = random.uniform(0, 0.1)+(0.25/45)*i
#       dc[1_1].append(a1)
#       dc[1_2].append(a2)
#       dc[2_1].append(a3)
#       dc[2_2].append(a4)
#   elif 45<i<=105:
#     a1 = random.uniform(0.4,0.5)
#     a2 = random.uniform(0.3,0.4)
#     a3 = random.uniform(0.4,0.5)
#     a4 = random.uniform(0.3,0.4)
#     dc[1_1].append(a1)
#     dc[1_2].append(a2)
#     dc[2_1].append(a3)
#     dc[2_2].append(a4)
#   elif 105 < i <= 150:
#       a1 = random.uniform(1.5, 1.6)+(-0.45/45)*i
#       a2 = random.uniform(1.1, 1.2)+(-0.35/45)*i
#       a3 = random.uniform(1.5, 1.6)+(-0.45/45)*i
#       a4 = random.uniform(1.1, 1.2)+(-0.35/45)*i
#       dc[1_1].append(a1)
#       dc[1_2].append(a2)
#       dc[2_1].append(a3)
#       dc[2_2].append(a4)
#   else:
#       dc[1_1].append(0)
#       dc[1_2].append(0)
#       dc[2_1].append(0)
#       dc[2_2].append(0)
# for i in range(1700):
#  if i < 150:
#     db[1_1].append(10/120)
#     db[1_2].append(10/120)
#     db[2_1].append(10/120)
#     db[2_2].append(10/120)                     # 以上需求全部暂定，需要改动
#  else:
#      db[1_1].append(0)
#      db[1_2].append(0)
#      db[2_1].append(0)
#      db[2_2].append(0)
# for i in range(1700):
#     x.append(i)
#     d[1_1].append(db[1_1][i]+dc[1_1][i])
#     d[1_2].append(db[1_2][i]+dc[1_2][i])
#     d[2_1].append(db[2_1][i]+dc[2_1][i])
#     d[2_2].append(db[2_2][i]+dc[2_2][i])
# print(d)
# plt.figure(figsize=(6,4))
# plt.rcParams['font.sans-serif']=['SimHei']
# plt.rcParams['axes.unicode_minus']=False
# plt.xlabel('time(2min)')
# plt.ylabel('demand(veh/sec)')
# plt.plot(x,d[1_1],label='d11',linewidth=0.5)
# plt.plot(x,d[1_2],label='d12',linewidth=0.5)
# plt.plot(x,d[2_1],label='d21',linewidth=0.5)
# plt.plot(x,d[2_2],label='d22',linewidth=0.5)
# plt.legend(loc='upper left')
# plt.title('低需求')
# plt.show()

# ############## 产生高需求，控制300步，一步三次需求 #############
# for i  in range(1700):
#    if i<=45:
#        a1 = random.uniform(0, 0.1)+(0.3/45)*i
#        a2 = random.uniform(0, 0.1)+(0.3/45)*i
#        a3 = random.uniform(0, 0.1)+(0.3/45)*i
#        a4 = random.uniform(0, 0.1)+(0.3/45)*i
#        dc[1_1].append(a1)
#        dc[1_2].append(a2)
#        dc[2_1].append(a3)
#        dc[2_2].append(a4)
#    elif 45<i<=105:
#      a1 = random.uniform(0.2,0.3)
#      a2 = random.uniform(0.2,0.3)
#      a3 = random.uniform(0.2,0.3)
#      a4 = random.uniform(0.2,0.3)
#      dc[1_1].append(a1)
#      dc[1_2].append(a2)
#      dc[2_1].append(a3)
#      dc[2_2].append(a4)
#    elif 105 < i <= 150:
#        a1 = random.uniform(1,1.2)+(-0.3/45)*i
#        a2 = random.uniform(1,1.2)+(-0.3/45)*i
#        a3 = random.uniform(1,1.2)+(-0.3/45)*i
#        a4 = random.uniform(1,1.2)+(-0.3/45)*i
#        dc[1_1].append(a1)
#        dc[1_2].append(a2)
#        dc[2_1].append(a3)
#        dc[2_2].append(a4)
#    else:
#        dc[1_1].append(0)
#        dc[1_2].append(0)
#        dc[2_1].append(0)
#        dc[2_2].append(0)
#
# for i in range(1700):
#   if i < 150:
#       db[1_1].append(10 / 120)
#       db[1_2].append(10/120)
#       db[2_1].append(10/120)
#       db[2_2].append(10/120)                     # 以上需求全部暂定，需要改动
#   else:
#       db[1_1].append(0)
#       db[1_2].append(0)
#       db[2_1].append(0)
#       db[2_2].append(0)
#
# for i in range(1700):
#      x.append(i)
#      d[1_1].append(db[1_1][i]+dc[1_1][i])
#      d[1_2].append(db[1_2][i]+dc[1_2][i])
#      d[2_1].append(db[2_1][i]+dc[2_1][i])
#      d[2_2].append(db[2_2][i]+dc[2_2][i])
# print(d)
# plt.figure(figsize=(6,4))
# plt.rcParams['font.sans-serif']=['SimHei']
# plt.rcParams['axes.unicode_minus']=False
# plt.xlabel('time(2min)')
# plt.ylabel('demand(veh/sec)')
# plt.plot(x,d[1_1],label='d11',linewidth=0.5)
# plt.plot(x,d[1_2],label='d12',linewidth=0.5)
# plt.plot(x,d[2_1],label='d21',linewidth=0.5)
# plt.plot(x,d[2_2],label='d22',linewidth=0.5)
# plt.legend(loc='upper left')
# plt.title('高需求')
# plt.show()



# ############## 试验低 #############
for i  in range(1700):
   if i<=45:
       dc[1_1].append(0.01)
       dc[1_2].append(0.01)
       dc[2_1].append(0.01)
       dc[2_2].append(0.01)
   elif 45<i<=105:
        dc[1_1].append(0.05)
        dc[1_2].append(0.05)
        dc[2_1].append(0.05)
        dc[2_2].append(0.05)
   elif 105 < i <= 150:
          dc[1_1].append(0.01)
          dc[1_2].append(0.01)
          dc[2_1].append(0.01)
          dc[2_2].append(0.01)
   else:
          dc[1_1].append(0)
          dc[1_2].append(0)
          dc[2_1].append(0)
          dc[2_2].append(0)
for i in range(1700):
 if i < 150:
     db[1_1].append(10/120)
     db[1_2].append(10/120)
     db[2_1].append(10/120)
     db[2_2].append(10/120)                     # 以上需求全部暂定，需要改动
 else:
     db[1_1].append(0)
     db[1_2].append(0)
     db[2_1].append(0)
     db[2_2].append(0)
#
for i in range(1700):
       x.append(i)
       d[1_1].append(db[1_1][i]+dc[1_1][i])
       d[1_2].append(db[1_2][i]+dc[1_2][i])
       d[2_1].append(db[2_1][i]+dc[2_1][i])
       d[2_2].append(db[2_2][i]+dc[2_2][i])
print(d)

############## 试验高 #############
# for i  in range(500):
#    if i<=45:
#        dc[1_1].append((0.3/45)*i)
#        dc[1_2].append((0.2/45)*i)
#        dc[2_1].append((0.5/45)*i)
#        dc[2_2].append((0.3/45)*i)
#    elif 45<i<=105:
#      dc[1_1].append(0.3)
#      dc[1_2].append(0.2)
#      dc[2_1].append(0.5)
#      dc[2_2].append(0.3)
#    elif 105 < i <= 150:
#        dc[1_1].append(1+(-0.3/45)*i)
#        dc[1_2].append(2/3+(-0.2/45)*i)
#        dc[2_1].append(5/3+(-0.5/45)*i)
#        dc[2_2].append(1+(-0.3/45)*i)
#    else:
#        dc[1_1].append(0)
#        dc[1_2].append(0)
#        dc[2_1].append(0)
#        dc[2_2].append(0)
#
# for i in range(500):
#   if i < 150:
#       db[1_1].append(10/120)
#       db[1_2].append(10/120)
#       db[2_1].append(10/120)
#       db[2_2].append(10/120)                     # 以上需求全部暂定，需要改动
#   else:
#       db[1_1].append(0)
#       db[1_2].append(0)
#       db[2_1].append(0)
#       db[2_2].append(0)
#
# for i in range(500):
#      x.append(i)
#      d[1_1].append(db[1_1][i]+dc[1_1][i])
#      d[1_2].append(db[1_2][i]+dc[1_2][i])
#      d[2_1].append(db[2_1][i]+dc[2_1][i])
#      d[2_2].append(db[2_2][i]+dc[2_2][i])

# print(d)

plt.figure(figsize=(6,4))
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False
plt.xlabel('time(2min)')
plt.ylabel('demand(veh/sec)')
plt.plot(x,d[1_1],label='d11',linewidth=0.5)
plt.plot(x,d[1_2],label='d12',linewidth=0.5)
plt.plot(x,d[2_1],label='d21',linewidth=0.5)
plt.plot(x,d[2_2],label='d22',linewidth=0.5)
plt.legend(loc='upper left')
plt.title('高需求')
plt.show()