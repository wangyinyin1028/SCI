import random

pop1=[]
for i in range(10):
    a = random.randint(0, 2)
    pop1.append(a)
print(pop1)
