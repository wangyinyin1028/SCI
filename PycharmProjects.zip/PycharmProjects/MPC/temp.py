from test import uuuuu,u112,u221
import xlwt
print(uuuuu)
import xlwt

def data_write():
    f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'sheet1',cell_overwrite_ok=True) #创建sheet
    # title = []  #加入表头
    # datas.insert(0, title) #写入表头
    style = xlwt.XFStyle() #创建样式
    align = xlwt.Alignment() #创建对齐方式
    align.horz = 1  #1-->左对齐，2-->居中，3-->右对齐
    style.alignment = align
    #将数据写入第 i 行，第 j 列
    for i in range(len(u221)):
        sheet1.write(i+1,1,u221[i],style=style)
        sheet1.write(i+1,2,u112[i], style=style)
    f.save('E:\\wyy\\PycharmProjects\\MPC\\u10.xls') #保存文件
data_write()