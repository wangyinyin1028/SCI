import numpy as np
import  math
import random
from test_de import d,db,dc
import matplotlib.pyplot as plt

## MFD模型参数
N1 = 100
n11 = 80
n12 = 50
N2 = 160
n21 = 50
n22 = 40
N1_C = 9396
N2_C = 6338
N1_JAM = 20000
N2_JAM = 12500
l = [31.04, 21.415]#区域1与区域2的路网总体长度
l1 =[3.1,2.9,3.0,3.3]#四个路口的长度
l2 =[1.9,2.1,2.0,1.3]
t_p = 20  # 预测步数
t_c = 360  # 控制时间 单位为秒
C = 120
t_s = 300  # 控制步数
G1 = -3E-08* pow(N1, 2) + 6E-04 *N1 + 0.0183
G2 = -6E-08*pow(N2, 2) + 8E-04 *N2  + 0.0399
m11 = (n11 / N1) * G1
m12 = (n12 / N1) * G1
m22 = (n22 / N2) * G2
m21 = (n21 / N1) * G2

########### 信号周期120s，一步设定2分钟（120s），控制300步 ############



#####################################first_layer参数#######################################
n_p = {1_1: np.ones(900), 1_2: np.ones(900), 2_1: np.ones(900), 2_2: np.ones(900)}
N_p = {'区域1': np.ones(900), '区域2': np.ones(900)}
m = {1_1: np.ones(900), 1_2: np.ones(900), 2_1: np.ones(900), 2_2: np.ones(900)}
G = {'区域1': np.ones(900), '区域2': np.ones(900)}
vc = {'区域1': np.ones(900), '区域2': np.ones(900)}
#############################  first_layer参数  #################################################
########################### first_layer 计算边界控制参数U，遗传算法##################
### 确定精度
def delta():
            for i in range(1, 50):
                if (b - a) / e < 2 ** i:
                    break
                else:
                    i = i + 1
                m = i
                chrom_length = 2 * m * t_p
            return chrom_length

############ 通过geneEncoding函数生成简单随机序列的函数
def geneEncoding(pop_size, chrom_length):
            pop = [[]]
            for i in range(pop_size):
                temp = []
                for j in range(chrom_length):
                    temp.append(random.randint(0, 1))
                pop.append(temp)
            return (pop[1:])  # 返回pop的第2位到最后一位，例如 x = "abcdef" ，x = x[1:] ，print x ，结果为："bcdef"


def decodechrom(pop, chrom_length):  # 通过 decodechrom函数将二进制转化为十进制
            temp = [[]]
            for i in range(pop_size):
                tem = []
                t = 0
                for j in range(int(2 * t_p)):
                    for k in range(int(chrom_length / (2 * t_p))):
                        t += pop[i][j * 10 + k] * (math.pow(2, k))
                    u = t / (math.pow(2, chrom_length / (2 * t_p)) - 1)
                    tem.append(u)
                    t = 0
                temp.append(tem)
            return temp


def calobjValue(pop, chrom_length): ### 通过MPC获得预测步数内的区域内累计车辆数和完成流，以m/N的最大值作为适应度
            obj_value = []
            u = decodechrom(pop, chrom_length)
            for i in range(len(u[1:])):
                f1 = 0
                f2 = 0

                for k in range(curent_t, curent_t + t_p - 1):
                    n_p[1_1][k + 1] = n_p[1_1][k] + C * (d[1_1][k]) + t_c * (u[i + 1][k - curent_t + 20] * m[2_1][k] - m[1_1][k])  # 调用decodechrom(pop,chrom_length)后u的前20个值是1—2，后20个值是2—1
                    n_p[1_2][k + 1] = n_p[1_2][k] + C * (d[1_2][k]) - t_c * (u[i + 1][k - curent_t] * m[1_2][k])
                    n_p[2_2][k + 1] = n_p[2_2][k] + C * (d[2_2][k]) + t_c * (u[i + 1][k - curent_t] * m[1_2][k] - m[2_2][k])
                    n_p[2_1][k + 1] = n_p[2_1][k] + C * (d[2_1][k]) - t_c * (u[i + 1][k - curent_t + 20] * m[2_1][k])
                    if n_p[1_1][k + 1] < 0:
                        n_p[1_1][k + 1] = 0
                    elif n_p[1_2][k + 1] < 0:
                        n_p[1_2][k + 1] = 0
                    elif n_p[2_2][k + 1] < 0:
                        n_p[2_2][k + 1] = 0
                    elif n_p[2_1][k + 1] < 0:
                        n_p[2_1][k + 1] = 0

                    N_p['区域1'][k + 1] = n_p[1_1][k + 1] + n_p[1_2][k + 1]
                    N_p['区域2'][k + 1] = n_p[2_1][k + 1] + n_p[2_2][k + 1]

                    G['区域1'][k + 1] = -3E-09 * pow(N_p['区域1'][k + 1], 2) + 6E-05 * (N_p['区域1'][k + 1]) + 0.0183
                    G['区域2'][k + 1] = -6E-09 * pow(N_p['区域2'][k + 1], 2) + 8E-05 * (N_p['区域2'][k + 1]) + 0.0399

                    # print(vc)
                    if G['区域1'][k + 1] < 0:
                        G['区域1'][k + 1] = 0
                    if G['区域2'][k + 1] < 0:
                        G['区域2'][k + 1] = 0
                    if N_p['区域1'][k + 1] == 0 or G['区域1'][k + 1] == 0:
                        m[1_1][k + 1] = 0
                        m[1_2][k + 1] = 0
                    else:
                        m[1_1][k + 1] = (n_p[1_1][k + 1] / N_p['区域1'][k + 1]) * G['区域1'][k + 1]
                        m[1_2][k + 1] = (n_p[1_2][k + 1] / N_p['区域1'][k + 1]) * G['区域1'][k + 1]
                    if N_p['区域2'][k + 1] == 0 or G['区域2'][k + 1] == 0:
                        m[2_1][k + 1] = 0
                        m[2_2][k + 1] = 0
                    else:
                        m[2_1][k + 1] = (n_p[2_1][k + 1] / N_p['区域2'][k + 1]) * G['区域2'][k + 1]
                        m[2_2][k + 1] = (n_p[2_2][k + 1] / N_p['区域2'][k + 1]) * G['区域2'][k + 1]

                    if N_p['区域1'][k + 1] > 0:
                        vc['区域1'][k + 1] = G['区域1'][k + 1] / (N_p['区域1'][k + 1] / (l[0] * 1000))
                    else:
                        vc['区域1'][k + 1] = 16.7  # 限速60
                    if N_p['区域1'][k + 1] > 0:
                        vc['区域2'][k + 1] = G['区域2'][k + 1] / (N_p['区域2'][k + 1] / (l[1] * 1000))
                    else:
                        vc['区域2'][k + 1] = 16.7  # 限速60

                    if vc['区域1'][k + 1] < 0:
                        vc['区域1'][k + 1] = 0
                    # if vc['区域1'][k + 1] > 16.7:
                    #     vc['区域1'][k + 1] = 16.7
                    if vc['区域2'][k + 1] < 0:
                        vc['区域2'][k + 1] = 0
                    # if vc['区域1'][k + 1] > 16.7:
                    #     vc['区域1'][k + 1] = 16.7

                    f1 += N_p['区域1'][k+1] + N_p['区域2'][k+1]
                    f2 += m[2_2][k+1] + m[1_1][k+1]  # 由于需求设置使得G为0导致m为0，故f2为0，存在问题（可能是G的函数存在问题）

                f = f2 / f1
                obj_value.append(f)
            # print(obj_value)
            # print(len(obj_value))

            return obj_value


        ###########去除obj_value中的负值与无穷值
def calfiValue(obj_value):
            fit_value = []
            # c_min = 0
            # (m, obj_value) = calobjValue(pop, chrom_length)

            for i in range(len(obj_value)):
                if (obj_value[i] > 0 and obj_value[i] < float('inf')):
                    temp = obj_value[i]
                else:
                    temp = 0.0
                fit_value.append(temp)
            return fit_value


def sum(fit_value):
            total = 0
            for i in range(len(fit_value)):
                total += fit_value[i]
            return total


def cumsum(fit_value):
            for i in range(len(fit_value) - 2, -1, -1):
                t = 0
                j = 0
                while (j <= i):
                    t += fit_value[j]
                    j += 1
                fit_value[i] = t
                fit_value[len(fit_value) - 1] = 1


def selection(pop, fit_value):
            newfit_value = []
            total_fit = sum(fit_value)
            # if total_fit == 0:
            #     total_fit = 1
            for i in range(len(fit_value)):
                newfit_value.append(fit_value[i] / total_fit)
            cumsum(newfit_value)
            # print(newfit_value)

            ms = []
            for i in range(len(pop)):
                ms.append(random.random())
            ms.sort()

            fitin = 0
            newin = 0
            newpop = pop

            while newin < len(pop) and fitin < len(pop):
                if (ms[newin] < newfit_value[fitin]):
                    newpop[newin] = pop[fitin]
                    newin += 1
                else:
                    fitin += 1
            pop = newpop
            return pop


        ########### 进行交叉
def crossover(pop, pc):
            for i in range(len(pop) - 1):
                if (random.random() < pc):
                    cpoint = random.randint(0, delta())
                    temp1 = []
                    temp2 = []
                    temp1.extend(pop[i][0:cpoint])
                    temp1.extend(pop[i + 1][cpoint:len(pop[i])])
                    temp2.extend(pop[i + 1][0:cpoint])
                    temp2.extend(pop[i + 1][cpoint:len(pop[i])])
                    pop[i] = temp1
                    pop[i + 1] = temp2
            return pop


        ############ 进行变异
def mutation(pop, pm):
            for i in range(len(pop)):
                if (random.random() < pm):
                    mpoint = random.randint(0, len(pop[0]) - 1)
                    if (pop[i][mpoint] == 1):
                        pop[i][mpoint] = 0
                    else:
                        pop[i][mpoint] = 1
            return pop


        # 找出最优值
def best(pop, fit_value):
            px = len(pop)
            best_individual = []
            best_fit = fit_value[0]
            for i in range(px):
                if fit_value[i] > best_fit:
                    best_fit = fit_value[i]
                    best_individual = pop[i]
            # print(best_individual)
            return best_individual, best_fit


        # 将二进制转化为十进制
def b2d(best_individual):
            length = len(best_individual)
            u_best = []
            t = 0
            for i in range(int(2 * t_p)):
                for k in range(int(length / (2 * t_p))):
                    t += best_individual[i * 10 + k] * (math.pow(2, k))
                u = t / (math.pow(2, chrom_length / (2 * t_p)) - 1)
                u_best.append(u)
                t = 0
            a = [u_best[0], u_best[19]]
            return a  # u_best[0]是在t时刻u12的最优值，u_best[19]是在t时刻u21的最优值


a = 0
b = 1
pop_size = 60
pc = 0.8
pm = 0.05
e = 0.001
t = 0

fit_value = []  # 个体适应度
fit_mean = []  # 平均适应度

pop = geneEncoding(pop_size, delta())
chrom_length = delta()



def results():
            for i in range(pop_size):
                obj_value = calobjValue(pop, chrom_length)  # 个体评价
                fit_value = calfiValue(obj_value)  # 淘汰
                # best_individual, best_fit = best(pop,fit_value)  # 第一个存储最优的解, 第二个存储最优基因
                # results.append([best_fit, best_individual])
                selection(pop, fit_value)  # 选择
                crossover(pop, pc)  # 交叉
                mutation(pop, pm)  # 变异
                best_individual, best_fit = best(pop, fit_value)  # 第一个存储最优的解, 第二个存储最优基因
                u_best = b2d(best_individual)
                for i in range(2):
                    if u_best[i] <= 0.1:
                        u_best[i] = 0.1
            print("u_best"+str(u_best))
            #print(u_best)
            uuuuu.append(u_best)
            # print("uuuuu"+str(uuuuu))
            # print(uuuuu)
            # results.append(b2d(best_individual))
            # results = [u_best,best_fit]
            return (u_best)
# u = results()
################################## first_layer ################################################
N11111 = []
N22222 = []
m11111 = []
m22222 = []
vc1111 = []
vb1111 = []
vc2222 = []
vb2222 = []
gl = []
gs = []
uuuuu=[]
G1111=[]
G2222=[]
vc1 = 0
vc2 = 0
HET1=[]
HET2=[]
ob1=[]
for  curent_t in range(150):
    print(curent_t)
    print()
    u = results()
    # print(u)

u112 = []
u221 = []
y=[]
for i in range(len(uuuuu)):
    u112.append(uuuuu[i][0])
    u221.append(uuuuu[i][1])
    y.append(i)
plt.figure(figsize=(20,6))
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False
plt.subplot(212)
plt.ylabel('U',fontsize=15,family= 'Times New Roman')
plt.xlabel('Time(2 min)',fontsize=15,family= 'Times New Roman')
plt.xticks(fontsize=15,family= 'Times New Roman')
plt.yticks(fontsize=15,family= 'Times New Roman')
plt.title('In high demand',fontsize=15,family= 'Times New Roman')
plt.ylim(0,1)
plt.plot(y,u112,label="u12")
plt.plot(y,u221,label="u21")
plt.grid(True)
plt.show()