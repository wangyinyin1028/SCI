import numpy as np
import random
import matplotlib.pyplot as plt
dc = {1_1: [], 1_2: [], 2_1: [], 2_2: []}
db = {1_1: [], 1_2: [], 2_1: [], 2_2: []}
d = {1_1: [], 1_2: [], 2_1: [], 2_2: []}
x =[]
# ############## 产生高需求，控制300步，一步三次需求 #############
for i  in range(1700):
   if i<=45:
       a1 = random.uniform(0, 0.1)+(0.9/45)*i
       a2 = random.uniform(0, 0.1)+(0.9/45)*i
       a3 = random.uniform(0, 0.1)+(0.5/45)*i
       a4 = random.uniform(0, 0.1)+(0.5/45)*i
       dc[1_1].append(a1)
       dc[1_2].append(a2)
       dc[2_1].append(a3)
       dc[2_2].append(a4)
   elif 45<i<=105:
     a1 = random.uniform(0.9,1)
     a2 = random.uniform(0.9,1)
     a3 = random.uniform(0.5,0.6)
     a4 = random.uniform(0.5,0.6)
     dc[1_1].append(a1)
     dc[1_2].append(a2)
     dc[2_1].append(a3)
     dc[2_2].append(a4)
   elif 105 < i <= 150:
       a1 = random.uniform(2.95,3.1)+(-0.9/45)*i
       a2 = random.uniform(2.95,3.15)+(-0.9/45)*i
       a3 = random.uniform(1.65,1.75)+(-0.5/45)*i
       a4 = random.uniform(1.65,1.75)+(-0.51/45)*i
       dc[1_1].append(a1)
       dc[1_2].append(a2)
       dc[2_1].append(a3)
       dc[2_2].append(a4)
   else:
       dc[1_1].append(0)
       dc[1_2].append(0)
       dc[2_1].append(0)
       dc[2_2].append(0)

for i in range(1700):
  if i < 150:
      db[1_1].append(10 / 120)
      db[1_2].append(10/120)
      db[2_1].append(10/120)
      db[2_2].append(10/120)                     # 以上需求全部暂定，需要改动
  else:
      db[1_1].append(0)
      db[1_2].append(0)
      db[2_1].append(0)
      db[2_2].append(0)

for i in range(350):
     x.append(i)
     d[1_1].append(db[1_1][i]+dc[1_1][i])
     d[1_2].append(db[1_2][i]+dc[1_2][i])
     d[2_1].append(db[2_1][i]+dc[2_1][i])
     d[2_2].append(db[2_2][i]+dc[2_2][i])
print(d)
plt.figure(figsize=(6,4))
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False
plt.xlabel('time(2min)')
plt.ylabel('demand(veh/sec)')
plt.plot(x,d[1_1],label='d11',linewidth=0.5)
plt.plot(x,d[1_2],label='d12',linewidth=0.5)
plt.plot(x,d[2_1],label='d21',linewidth=0.5)
plt.plot(x,d[2_2],label='d22',linewidth=0.5)
plt.legend(loc='upper left')
plt.title('高需求')
plt.show()

