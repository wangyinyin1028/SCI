#抽象基类（abc模块），在基础类中设定一些方法，继承该类的类都会含有这些方法；抽象基础类无法实例化
#我们取检查某个类是否有某种方法:检查company是否有长度
from collections.abc import Sized
'''
class Company(object):
    def __init__(self,employee_list):
        self.employee=employee_list
    def __len__(self):
        return len(self.employee)
company=Company(["tom","bobo","jack"])
print(hasattr(company,"__len__",))
#我们在某些情况下判定某个对象的类型
isinstance(company,Sized)
print(len(company))
#我们需要强制某个子类必须实现某些方法
#实现一个web框架，集成cache(redis,cache,memorychache)
#需要设计一个抽象类型，指定子类必须实现某些方法

#ImoocWeb
class CacheBase():
    def __get__(self, key):
        raise NotImplementedError
    def set(self, key, value):
        raise NotImplementedError
class RedisCache(CacheBase):
    def set(self, key, value):
        pass
redis_cache=RedisCache()
redis_cache.set("key","value")'''
class A:
    pass
class B(A):
    pass
b=B()
print(isinstance(b,A))