class A:
    pass
class B(A):
    pass
b=B()
print(isinstance(b,B))
print(isinstance(b,A))
print(type(b) == B)
id(b)
print(type(b) is A)#type(b)is B，B不等于A
#is 和==：==判断是否为同一个对象，