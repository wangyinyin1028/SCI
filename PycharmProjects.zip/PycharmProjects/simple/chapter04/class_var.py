class A:
    aa=1
    def __init__(self,x,y):
        self.X=x
        self.Y=y
a=A(2,3)
b=A(6,6)
A.aa=11#修改的是类变量
a.aa=12#对于实例新建的一个对象
print(a.aa,a.X,a.Y)
print(A.aa)
print(b.aa)