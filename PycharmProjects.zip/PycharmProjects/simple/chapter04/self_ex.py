#自省是通过一定的机制查询到对象的内部结构
#from chapter04.class_method import Date
class Person():
    name = "user"
class Student(Person):
    def __init__(self,school_name):
        self.school_name=school_name


if __name__=="__main__":
    user=Student("MOOC")
   #通过__dict__查询属性,name是属于Person的属性，所以user的属性里没有name,可以调用name
    print(user.__dict__)
    print(user.name)
    print(Person.__dict__)

