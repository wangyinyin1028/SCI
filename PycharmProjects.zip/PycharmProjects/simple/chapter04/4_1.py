class Cat(object):
    def Say(self):
        print("我是一只猫")
    def __getitem__(self, item):
         return "mimi"
class Dog(object):
    def Say(self):
        print("我是一只狗")
    def __getitem__(self, item):
         return "boby"
class Duck(object):
    def Say(self):
        print("我是一只鸭")
class Company(object):
    def __init__(self,employee_list):
        self.employee=employee_list
    def __getitem__(self, item):
        return self.employee[item]
company=Company(["tom","bobo","jack"])
dog=Dog()

#animal=Cat
#animal().Say()
animal_list=[Cat,Dog,Duck]
for i in animal_list:
    i().Say()
'''class Animal():
    def Say(self):
        print("我是一只动物")
class Cat(Animal):
    def Say(self):
        print("我是一只猫")
Animal_an=Cat()'''

a=["bob1","bob2"]
b=["bob2","bob1"]
name_tuple=["bob3","bob4"]
name_set=set()
name_set.add("bob5")
name_set.add("bob6")
a.extend(b)
print(a)
a.extend(company)
print(a)
print(a[1:2])
print(a[0:2])