#赋值给一个对象
#如果函数没有return，则默认返回none
def ask(name="hobby"):
    print (name)

#init函数本身不返回实例，返回类的对象
class Person:
    def __init__(self):
        print("hobby1")

def decorator_type(item):
    print(type(item))

def decorator_func():
    print("dec start")
    return ask
#decorator_func赋给my_ask，return回ask.此时即将ask赋给my_ask
my_ask=decorator_func()
my_ask("tom")

'''obj_list=[]
obj_list.append(ask)
obj_list.append(Person)
for item in obj_list:
    print(item())

my_func=ask#将函数赋给变量，可以将变量当函数使用
my_func("hobby")

my_class=Person
my_class()'''