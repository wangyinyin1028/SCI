a=1
b="abc"
print(type(1))
print(type(int))
print(type(b))
print(type(str))
#ytpe_>int_>1
#ytpe_>class->obj
#object是最顶层基类
#type是个类也是一个对象，objec.bases是空的

class Student:
    pass
class Mystudent(Student):
    pass
stu=Student()
print(type(stu))
print(type(Student))
print(int.__base__)
print(str.__base__)
print(Student.__base__)
print(Mystudent.__base__)
print(type.__base__)
print(object.__base__)
print(type(object))

