import win32com.client as com
import pandas as pd
import os
import matplotlib.pyplot as plt
import numpy as np
os.chdir('E:\\VISSIM430\\Example\\wyy_excise\\busline_2')
tem = pd.read_table('busline.rsz', encoding='gbk')
# print(tem)
print(tem[7:].reset_index(drop=True))#截取7行以下的内容
tem = tem[7:].reset_index(drop=True)
tem.columns = ['DATA']
tem1 = pd.DataFrame([var.split(';') for var in tem.DATA])
tem1.columns = ['time', 'travaltime', 'vehiclenumber','id']#分号后面也成一列，所以id是空值
tem1.drop(['id'],axis=1,inplace=True)
# print(tem1)
print(tem1.loc[:10,['time', 'travaltime']])
#
fig, ax = plt.subplots(nrows=1, ncols=2)
ax[0].plot(tem1['time'].astype(float),tem1['travaltime'].astype(float), 'o-', label='travaltime')
ax[1].plot(tem1['time'].astype(float),tem1['vehiclenumber'].astype(float), 'o-', label='vehiclenumber')
# #
ax[0].legend()
ax[1].legend()
plt.show()