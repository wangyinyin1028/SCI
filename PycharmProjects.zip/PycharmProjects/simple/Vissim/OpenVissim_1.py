import win32com.client as com  # VISSIM COM
class OpenVissim():  # 继承Problem父类
        def __init__(self, filename):
            self.incident = 0
            self.Vissim = com.Dispatch("Vissim.Vissim")
            dir = filename
            self.Vissim.LoadNet(dir)
            # Define Simulation Configurations
            graphics = self.Vissim.Graphics
            graphics.SetAttValue("VISUALIZATION", False)  ## 设为 不可见 提高效率
            self.Sim = self.Vissim.Simulation
            self.Net = self.Vissim.Net
            self.eval = self.Vissim.Evaluation
            print("载入路网完成！")
            self.decisions = self.Net.DesiredSpeedDecisions
            self.datacollections = self.Net.datacollections

        def runSimulation(self, accidentStartTime, accidentEndTime, totalPeriod):
            global vehicle4, vehicle3, vehicle2, vehicle1
            WarmPeriod = 900  # Define warm period 10 minutes
            Random_Seed = 42  # Define random seed
            step_time = 1  # Define Step Time
            # self.Sim.50
            self.Sim.RandomSeed = 42
            # self.Sim.RunIndex= 1
            self.Sim.Resolution = step_time
            self.eval.SetAttValue("vehiclerecord", True)
            self.eval.SetAttValue("datacollection", True)
            for j in range(1, totalPeriod):
                if j == accidentStartTime:
                    vehicle1 = self.Net.vehicles.AddVehicleAtLinkCoordinate(100, 10, 1, 1, 100, 0)
                    vehicle2 = self.Net.vehicles.AddVehicleAtLinkCoordinate(100, 10, 1, 2, 50, 0)
                    vehicle3 = self.Net.vehicles.AddVehicleAtLinkCoordinate(100, 10, 1, 2, 25, 0)
                    vehicle4 = self.Net.vehicles.AddVehicleAtLinkCoordinate(100, 10, 1, 1, 0, 0)
                    vehicle1.SetAttValue("speed", 0)
                    vehicle2.SetAttValue("speed", 0)
                    vehicle3.SetAttValue("speed", 0)
                    vehicle4.SetAttValue("speed", 0)
                    self.incident = 1
                    print("t=", j, "事故发生")
                if j == accidentEndTime:
                    vehicles_ = self.Net.Vehicles
                    print(vehicles_.count)
                    vehicle1.SetAttValue("speed", 10)
                #     vehicle2.SetAttValue("speed", 10)
                #     vehicle3.SetAttValue("speed", 10)
                #     vehicle4.SetAttValue("speed", 10)
                #     vehicle1.SetAttValue("DESIREDspeed", 20)
                #     vehicle2.SetAttValue("DESIREDspeed", 20)
                #     vehicle3.SetAttValue("DESIREDspeed", 20)
                #     vehicle4.SetAttValue("DESIREDspeed", 20)
                    print("t=", j, "事故撤销")
                if j == accidentEndTime + 100:
                    self.incident = 0
                    print("t=", j, "VMS结束")
                self.Sim.RunSingleStep()
            self.Sim.Stop()
            print("仿真结束")
accidentStartTime = 100
accidentEndTime = 300
totalPeriod = 500
filename='E:\\VISSIM430\\Example\\wyy_excise\\test\\fenghuang.inp'
openVissim=OpenVissim(filename)
openVissim.runSimulation(accidentStartTime, accidentEndTime, totalPeriod)
