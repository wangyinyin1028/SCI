import win32com.client as com  # VISSIM COM
class OpenVissim():  # 继承Problem父类
        def __init__(self, filename,layout):
            self.Vissim = com.Dispatch("Vissim.Vissim")
            dir = filename
            self.Vissim.LoadNet(dir)
            self.Vissim.LoadLayout(layout)  # 加载配置文件
            self.Net = self.Vissim.Net
            # Define Simulation Configurations
            # graphics = self.Vissim.Graphics
            # graphics.SetAttValue("VISUALIZATION", False)  ## 设为 不可见 提高效率
        def configuration(self):
            self.Sim = self.Vissim.Simulation
            self.Net = self.Vissim.Net
            self.eval = self.Vissim.Evaluation
            self.routingdecisions=self.Net.routingdecisions
            print("载入路网完成！")
            self.datacollections = self.Net.datacollections
            self.vehicles_in = self.Net.VehicleInputs
        def evaluation(self):
            # # 打开离线评价按钮
            self.eval.SetAttValue('DATACOLLECTION', True)#打开vissim内部DATACOLLECTION数据收集按钮
            dceval = self.eval.DataCollectionEvaluation
            dceval.SetAttValue('FILE', True)
            dceval.SetAttValue('COMPILED', True)
            self.eval.SetAttValue("vehiclerecord", True)
            self.eval.SetAttValue("vehiclerecord", True)
            self.eval.SetAttValue("datacollection", True)
            self.Sim.RunContinuous()
        def vehicle_input(self,num):
            vehicles_input1 = self.Net.VehicleInputs.GetVehicleInputByNumber(1)  # 获取车辆输入
            vehicles_input1.SetAttValue('Volume', num)
            print(vehicles_input1.AttValue("Volume"))
        def simulation(self):
            step_time = 1  # Define Step Time
            self.Sim.RandomSeed = 42
            self.Sim.Resolution = step_time
            self.Sim.Period = 100
            self.Sim.Speed = 5
            self.Sim.RunIndex = 0
            self.Sim.RunContinuous()  # 仿真开始
        def BRT(self):
             self.link1 = self.Net.links.GetLinkByNumber(1)
             self.CONNECTOR = self.Net.links.GetLinkByNumber(10000)
             self.link2 = self.Net.links.GetLinkByNumber(2)
             #专用车道
             self.link1.SetAttValue2('LANECLOSED', 1, 10, True)
             self.link1.SetAttValue2('LANECLOSED', 1, 20, True)
             self.link1.SetAttValue2('LANECLOSED', 1, 40, True)
             self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 10, True)
             self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 20, True)
             self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 40, True)
             self.link2.SetAttValue2('LANECLOSED', 1, 10, True)
             self.link2.SetAttValue2('LANECLOSED', 1, 20, True)
             self.link2.SetAttValue2('LANECLOSED', 1, 40, True)
        def CONTINUE(self):
             self.link1 = self.Net.links.GetLinkByNumber(1)
             self.CONNECTOR = self.Net.links.GetLinkByNumber(10000)
             self.link2 = self.Net.links.GetLinkByNumber(2)
             self.link1.SetAttValue2('LANECLOSED', 1, 10, True)
             self.link1.SetAttValue2('LANECLOSED', 1, 20, True)
             self.link1.SetAttValue2('LANECLOSED', 1, 30, False)
             self.link1.SetAttValue2('LANECLOSED', 1, 40, True)
             self.link1.SetAttValue2('LANECLOSED', 1, 50, True)
             self.link1.SetAttValue2('LANECLOSED', 1, 60, True)

             self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 10, False)
             self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 20, False)
             self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 30, False)
             self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 40, False)
             self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 50, False)
             self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 60, False)

             self.link2.SetAttValue2('LANECLOSED', 1, 10, False)
             self.link2.SetAttValue2('LANECLOSED', 1, 20, False)
             self.link2.SetAttValue2('LANECLOSED', 1, 30, False)
             self.link2.SetAttValue2('LANECLOSED', 1, 40, False)
             self.link2.SetAttValue2('LANECLOSED', 1, 50, False)
             self.link2.SetAttValue2('LANECLOSED', 1, 60, False)
        def PRESIGNAL(self):
             self.link1 = self.Net.links.GetLinkByNumber(1)
             self.CONNECTOR = self.Net.links.GetLinkByNumber(10000)
             self.link2 = self.Net.links.GetLinkByNumber(2)
              # 专用车道
             self.link1.SetAttValue2('LANECLOSED', 1, 10, True)
             self.link1.SetAttValue2('LANECLOSED', 1, 20, True)
             self.link1.SetAttValue2('LANECLOSED', 1, 40, True)

        def lane_huanyuan(self):
            self.link1 = self.Net.links.GetLinkByNumber(1)
            self.CONNECTOR = self.Net.links.GetLinkByNumber(10000)
            self.link2 = self.Net.links.GetLinkByNumber(2)
            self.link1.SetAttValue2('LANECLOSED', 1, 10, False)
            self.link1.SetAttValue2('LANECLOSED', 1, 20, False)
            self.link1.SetAttValue2('LANECLOSED', 1, 30, False)
            self.link1.SetAttValue2('LANECLOSED', 1, 40, False)
            self.link1.SetAttValue2('LANECLOSED', 1, 50, False)
            self.link1.SetAttValue2('LANECLOSED', 1, 60, False)

            self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 10, False)
            self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 20, False)
            self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 30, False)
            self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 40, False)
            self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 50, False)
            self.CONNECTOR.SetAttValue2('LANECLOSED', 1, 60, False)

            self.link2.SetAttValue2('LANECLOSED', 1, 10, False)
            self.link2.SetAttValue2('LANECLOSED', 1, 20, False)
            self.link2.SetAttValue2('LANECLOSED', 1, 30, False)
            self.link2.SetAttValue2('LANECLOSED', 1, 40, False)
            self.link2.SetAttValue2('LANECLOSED', 1, 50, False)
            self.link2.SetAttValue2('LANECLOSED', 1, 60, False)
        def routedecision(self):
            self.routingdecisions = self.Net.routingdecisions#将路网中的路径决策加载
            self.routing1=self.routingdecisions.AddStaticRoutingDecision(1,5)#增加一个路径决策，在link1的10米处
            # print(self.routing1)#返回路径决策编号
            self.routes1=self.routingdecisions.GetRoutingDecisionByNumber(1).routes#该路径决策中的路由加载
            self.routenum_11=self.routes1.AddRoute(6,30)#在link8的30米处，理论上的决策1中的编号1的路由
            self.routenum_12 = self.routes1.AddRoute(5, 32)
            self.routenum_13 = self.routes1.AddRoute(4, 30)
            self.routenum_14 = self.routes1.AddRoute(3, 30)
            print(self.routenum_11)
            print(self.routenum_12)
            print(self.routenum_13)
            print(self.routenum_14)
            self.route11=self.routes1.GetRouteByNumber (1).SetAttValue1('RELATIVEFLOW',50,2)

            # route = vissim.Net.RouteDecisions(1).Routes.GetRouteByNumber(12)


            # self.decision2 = self.routing1.GetRoutingDecisionByNumber(2)
            # self.decision2.SetAttValue1('RELATIVEFLOW', 6,2)
            # self.decision2.SetAttValue1('RELATIVEFLOW', 2, 8)
            # self.routes = self.decision2.Routes
            # self.route21 = self.decision2.Routes.GetRouteByNumber(1)
            # print(self.route21.AttValue('RELATIVEFLOW'))



            # print(self.routingdecisions.Count)
            # self.decision1=self.routingdecisions.GetRoutingDecisionByNumber (1)
            # print(self.decision1.AttValue1('RELATIVEFLOW', 1))

            # # print(self.decision1._NewEnum)
            # # print(self.decision1.AttValue1('VEHICLECLASSES',1,))
            # print(self.decision1.AttValue('VEHICLECLASSES'))
            # print(self.decision1.AttValue('VEHICLETYPES'))



if __name__ == "__main__":

 filename='E:\\VISSIM430\\Example\\wyy_excise\\multi_busline3\\multi_busline3.inp'
 layout='E:\\VISSIM430\\Example\\wyy_excise\\multi_busline3\\multi_busline3.ini'
 openVissim=OpenVissim(filename,layout)
 openVissim.configuration()
 openVissim.lane_huanyuan()
 openVissim.CONTINUE()
 openVissim.vehicle_input(2500)
 openVissim.routedecision()
 openVissim.simulation()

