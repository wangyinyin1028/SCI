#接入模块
import win32com.client as com  # VISSIM COM
import pythoncom
import pandas as pd
from pandas import DataFrame
import numpy as np
import os
import matplotlib.pyplot as plt

# 启动程序,加载路网及布局文件
vissim_com = com.Dispatch("Vissim.Vissim")#接口
vissim_com.LoadNet('E:\\VISSIM430\\Example\\wyy_excise\\test\\fenghuang.inp')#加载路网
vissim_com.LoadLayout('E:\\VISSIM430\\Example\\wyy_excise\\test\\fenghuang.ini')#加载配置文件
vissim_com.net.name="wyy"
print(vissim_com.net.name)
print("载入路网完成！")
distance_unit1 = vissim_com.AttValue('UNITDISTANCE1')
print(distance_unit1)
vissim=vissim_com
print(vissim.GetWindow ('top','left','bottom','right'))
vissim.setWindow (50,0,800,1000)
#实例化类
vnet = vissim_com.net#路网实例化
Sim = vissim_com.Simulation #仿真传递给Sim
eval = vissim_com.Evaluation#将评价赋给eval

# 设置仿真参数并启动仿真
Sim.RandomSeed = 42
Sim.resolution=10
Sim.Period = 50
Sim.Speed = 5
Sim.RunIndex = 0
Sim.RunContinuous()#仿真开始


vehicles_in=vnet.VehicleInputs
print(vehicles_in.count)
vehin_1=vehicles_in.GetVehicleInputByNumber(1) #获取车辆输入
vehin_2=vehicles_in.GetVehicleInputByNumber(2)
vehin_1.SetAttValue('Volume', 500)
vehin_2.SetAttValue('Volume', 500)
print(vehin_1.AttValue("Volume"))

vehicles_=vnet.Vehicles
global vehicle_1
vehicle_1 = vnet.vehicles.AddVehicleAtLinkCoordinate (100, 10, 1, 1, 10, 0)
print(vehicles_.count)

for veh in vehicles_:
     print(veh.AttValue("VehType"))
Sim.Stop()
# vehin_1.SetAttValue("VOLUME", 500)
# vehin_2.SetAttValue("VOLUME(0)", 500)
# print(vehin_1.ID)
# print(vehin_2.Name)
# print(vnet.Vehicles.count)
#
# for veh in vnet.Vehicles:
#
#      print(veh.AttValue("VehType"))


# vehin_1.getAttribute('Volume')

# # for i in range(1,vehicles_in.count):
#    vehicles_in(i).set('AttValue','VOLUME',volume(i)) #为各路段赋予车辆流量




# 参数：（车辆类型、期望速度、LINK编号、车道编号（最外侧为1）、里程坐标XCoord、交互模式 0）
# vehicle = vnet.vehicles.AddVehicleAtLinkCoordinate (300, 10, 1, 1, 10, 0)
# vehicle.SetAttValue("speed", 3)
# links = vnet.Links
# Nodes = vnet.Nodes
# paths = vnet.Paths
# vehicles = vnet.Vehicles
# inps = vnet.VehicleInputs
# rds = vnet.RoutingDecision
# scs = vnet.SignalControllers
# colls = vnet.DataCollections
# qcs = vnet.QueueCounters
# tts = vnet.TravelTimes
# # 打开离线评价按钮
# eval.SetAttValue('DATACOLLECTION', True)#打开vissim内部DATACOLLECTION数据收集按钮
# dceval = eval.DataCollectionEvaluation
# dceval.SetAttValue('FILE', True)
# dceval.SetAttValue('COMPILED', True)
# eval.SetAttValue("vehiclerecord", True)
#
# decisions = vnet.DesiredSpeedDecisions
# datacollections = vnet.datacollections
# totalPeriod=500
# accidentEndTime=200
#
# vehicleinput = vnet.vehicleinputs.GetVehicleInputByNumber(1)
# for i  in vehicles_in.count:
#    vehicle_in(i)=vehicles_in.GetVehicleInputByNumber(i) %获取车辆输入
#
# global vehicle4, vehicle3, vehicle2, vehicle1
# for j in range(1, totalPeriod):
    # if j == 100:
    #     ###########
    #     ## Add Vehicle At Link Coordinate 参数：（车辆类型、期望速度、LINK编号、车道编号（最外侧为1）、里程坐标XCoord、交互模式 0）
    #     ###########
    #     vehicle1 = vnet.vehicles.AddVehicleAtLinkCoordinate(100, 10, 1, 1, 100, 0)
    #     vehicle2 = vnet.vehicles.AddVehicleAtLinkCoordinate(100, 10, 1, 1, 120, 0)
    #     vehicle3 = vnet.vehicles.AddVehicleAtLinkCoordinate(100, 10, 1, 1, 110, 0)
    #     vehicle4 = vnet.vehicles.AddVehicleAtLinkCoordinate(100, 10, 1, 1, 90, 0)
    #     vehicle1.SetAttValue("speed", 0)
    #     vehicle2.SetAttValue("speed", 0)
    #     vehicle3.SetAttValue("speed", 0)
    #     vehicle4.SetAttValue("speed", 0)
    #     # self.incident = 1
    # if j == accidentEndTime:
    #         vehicle1.SetAttValue("speed", 80)
    #         vehicle2.SetAttValue("speed", 80)
    #         vehicle3.SetAttValue("speed", 80)
    #         vehicle4.SetAttValue("speed", 80)
    #         vehicle1.SetAttValue("DESIREDspeed", 80)
    #         vehicle2.SetAttValue("DESIREDspeed", 80)
    #         vehicle3.SetAttValue("DESIREDspeed", 80)
    #         vehicle4.SetAttValue("DESIREDspeed", 80)
    #         print("t=", j, "事故撤销")
    # if j == 900 + 500:
    #     incident = 0
    #     print("t=", j, "VMS结束")
