import win32com.client as com
import pandas as pd
import os
from matplotlib import pyplot as plt
import numpy as np
import matplotlib as mpl
from datetime import datetime
import matplotlib.dates as mdates

mpl.rcParams['font.sans-serif'] = ['SimHei']  # 使图像正常显示中文标签
mpl.rcParams['axes.unicode_minus'] = False  # 使图像正常显示负号

# 设置横纵坐标的名称以及对应字体格式
font1 = {
    'weight': 'normal',
    'size': 15,
}

font2 = {
    'weight': 'normal',
    'size': 12,

}

#######路段车辆数#####################################################
def Num_fileread(dir,file):
    os.chdir(dir)
    tem = pd.read_table(file, encoding='gbk')
    # print(tem)
    # print(tem[14:].reset_index(drop=True))#截取7行以下的内容
    tem = tem[10:].reset_index(drop=True)
    tem.columns = ['DATA']
    tem1 = pd.DataFrame([var.split(';') for var in tem.DATA])
    tem1.columns = ['Measur', 'from', 'to','greenbus', 'total ', 'social','xx']#分号后面也成一列，所以id是空值
    # # tem1.drop(['id'],axis=1,inplace=True)
    # print(tem1)
    df=tem1
    df.to_excel('data.xls',sheet_name='data')

    #
    df1=df.iloc[(df['Measur']=='1').values,[2,3,4,5]]
    return df,df1
    # df2=df.iloc[(df['Measur']=='2').values,[0,1,2,3,4,5,6]]
    # df3=df.iloc[(df['Measur']=='3').values,[0,1,2,3,4,5,6]]
    # df4=df.iloc[(df['Measur']=='4').values,[0,1,2,3,4,5,6]]
    # return df,df1,df2,df3,df4

def picture1():
    fig=plt.figure(1)
    ax1=fig.add_subplot(111)
    d=df.iloc[(df['Measur']=='1').values,[2]].astype(float)
    print(type(d))

    ax1.plot(d,df.iloc[(df['Measur']=='1').values,[3]].astype(float), 'o-', label='road1_total')
    # ax1.plot(df.iloc[(df['Measur'] == '1').values, [2]].astype(float),df.iloc[(df['Measur'] == '1').values, [5]].astype(float), 'o-', label='road1_taxi')
    # ax1.plot(df.iloc[(df['Measur'] == '1').values, [2]].astype(float),df.iloc[(df['Measur'] == '1').values, [6]].astype(float), 'o-', label='road1_bus')
    # ax1.plot(df.iloc[(df['Measur'] == '1').values, [2]].astype(float),df.iloc[(df['Measur'] == '1').values, [4]].astype(float), 'o-', label='road1_social')
    ax1.legend()
    plt.grid(True)
    plt.ylabel('车辆数', font1)
    plt.xlabel('Time(10 min)', font1)
    plt.title('路口1通过的车辆数', font1)
    plt.show()

def picture2():
    fig = plt.figure(1)
    ax1 = fig.add_subplot(111)
    ax1.plot(df.iloc[(df['Measur'] == '2').values, [2]].astype(float),df.iloc[(df['Measur'] == '2').values, [3]].astype(float), 'o-', label='road2_total')
    ax1.plot(df.iloc[(df['Measur'] == '2').values, [2]].astype(float), df.iloc[(df['Measur'] == '2').values, [5]].astype(float), 'o-', label='road2_taxi')
    ax1.plot(df.iloc[(df['Measur'] == '2').values, [2]].astype(float), df.iloc[(df['Measur'] == '2').values, [6]].astype(float), 'o-', label='road2_bus')
    ax1.plot(df.iloc[(df['Measur'] == '2').values, [2]].astype(float),  df.iloc[(df['Measur'] == '2').values, [4]].astype(float), 'o-', label='road2_social')
    ax1.legend()

    plt.grid(True)
    plt.ylabel('车辆数', font1)
    plt.xlabel('Time(2 min)', font1)
    plt.title('路口2通过的车辆数', font1)
    plt.show()

def picture3():
    fig=plt.figure(1)
    ax1=fig.add_subplot(111)
    ax1.plot(df.iloc[(df['Measur'] == '3').values, [2]].astype(float),df.iloc[(df['Measur'] == '3').values, [3]].astype(float), 'o-', label='road3_total')
    ax1.plot(df.iloc[(df['Measur'] == '3').values, [2]].astype(float),df.iloc[(df['Measur'] == '3').values, [5]].astype(float), 'o-', label='road3_taxi')
    ax1.plot(df.iloc[(df['Measur'] == '3').values, [2]].astype(float),df.iloc[(df['Measur'] == '3').values, [6]].astype(float), 'o-', label='road3_bus')
    ax1.plot(df.iloc[(df['Measur'] == '3').values, [2]].astype(float),df.iloc[(df['Measur'] == '3').values, [4]].astype(float), 'o-', label='road3_social')
    ax1.legend()

    plt.grid(True)
    plt.ylabel('车辆数', font1)
    plt.xlabel('Time(2 min)', font1)
    # plt.xticks(fontsize=15,family= 'Times New Roman')
    # plt.yticks(fontsize=15,family= 'Times New Roman')
    plt.title('路口3通过的车辆数', font1)
    plt.show()

def picture4():
    fig = plt.figure(1)

    ax1 = fig.add_subplot(111)

    ax1.plot(df.iloc[(df['Measur']=='4').values,[2]].astype(float),df.iloc[(df['Measur']=='4').values,[3]].astype(float), 'o-', label='road4_total')
    ax1.plot(df.iloc[(df['Measur'] == '4').values, [2]].astype(float),df.iloc[(df['Measur'] == '4').values, [5]].astype(float), 'o-', label='road4_taxi')
    ax1.plot(df.iloc[(df['Measur'] == '4').values, [2]].astype(float),df.iloc[(df['Measur'] == '4').values, [6]].astype(float), 'o-', label='road4_bus')
    ax1.plot(df.iloc[(df['Measur'] == '4').values, [2]].astype(float),df.iloc[(df['Measur'] == '4').values, [4]].astype(float), 'o-', label='road4_social')
    ax1.legend()

    plt.grid(True)
    plt.ylabel('车辆数',font1)
    plt.xlabel('Time(2 min)',font1)
    # plt.xticks(fontsize=15,family= 'Times New Roman')
    # plt.yticks(fontsize=15,family= 'Times New Roman')
    plt.title('路口4通过的车辆数',font1)
    plt.show()
def road_passNum():
    # Num_fileread()
    picture1()
    picture2()
    picture3()
    picture4()

def delay():
    os.chdir('E:\\VISSIM430\\Example\\wyy_excise\\JIAOCHA_grop')
    temp = pd.read_table('jiaochakouqun.vlz', encoding='gbk')
    print(temp)
    print(temp[8:].reset_index(drop=True))  # 截取7行以下的内容
    temp1 = temp[8:].reset_index(drop=True)
    temp1.columns = ['DATA']
    temp2 = pd.DataFrame([var.split(';') for var in temp1.DATA])
    temp2.columns = ['time', 'delay_soci', 'stopd_soci', 'stops_soci', '#veh_soci', 'per_soci', '#per_soci', 'delay_b',
                     'stopd_b', 'stops_b', '#veh_b', 'per_b', '#per_b', '']  # 分号后面也成一列，所以id是空值
    temp3 = temp2.drop(index=[12, 13], inplace=False)
    print(temp3)
    plt.figure(figsize=(20, 6))
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    plt.subplot(212)
    plt.ylabel('delay(s)', fontsize=15, family='Times New Roman')
    plt.xlabel('Time(2 min)', fontsize=15, family='Times New Roman')
    plt.xticks(fontsize=15, family='Times New Roman')
    plt.yticks(fontsize=15, family='Times New Roman')
    plt.title('road1_delay', fontsize=15, family='Times New Roman')
    plt.plot(temp3['time'].astype(float), temp3['delay_soci'].astype(float), 'o-', label='delay_soci')
    plt.plot(temp3['time'].astype(float), temp3['delay_b'].astype(float), 'o-', label='delay_b')
    # plt.plot(temp3['time'].astype(float),temp3['per_soci'].astype(float), 'o-', label='per_soci')
    # plt.plot(temp3['time'].astype(float),temp3['per_b'].astype(float), 'o-', label='per_b')
    plt.grid(True)
    plt.legend()
    plt.show()
def dataframe_array(df):
    dd = []
    for i in range(len(df)):
        cc=[]
        a=np.array(df.iloc[i:i+1,2])#时间
        b = np.array(df.iloc[i:i + 1, 3])#车流量
        cc.append(int(a[0]))
        cc.append(int(b[0]))
        cc = np.array(cc)
        dd.append(cc)
    dd=np.array(dd)
    return dd
class travaltime():
    def __init__(self):
        self.Snum_bus=None
        self.Lnum_bus = None
        self.Rnum_bus = None
        self.S_TRA_bus = None
        self.L_TRA_bus = None
        self.R_TRA_bus = None

    def fileread(self):
        os.chdir('E:\\VISSIM430\\Example\\wyy_excise\\JIAOCHA_grop')
        tem = pd.read_table('jiaochakouqun.rsz', encoding='gbk')
        # print(tem)
        # print(tem[9:].reset_index(drop=True))#截取7行以下的内容
        tem = tem[9:].reset_index(drop=True)
        tem.columns = ['DATA']
        tem1 = pd.DataFrame([var.split(';') for var in tem.DATA])
        # print(tem1)
        tem1.columns = ['NO', 'TravalTime_s', 'Num_bus_s','TravalTime_l', 'Num_bus_l','TravalTime_r', 'Num_bus_r',' ']  # 分号后面也成一列，所以id是空值
        tem1.drop([' '],axis=1,inplace=True)
        # print(tem1)
        return tem1

    def dataframe_array(self,tem1):
        df=tem1
        dd = []
        for i in range(len(df)):
            cc = []
            t=df.iat[i,0]
            a = df.iat[i,1]  # 时间
            b = df.iat[i,3]  # 路段行程时间
            c = df.iat[i,5]  # 路段行程时间

            t = int(t)
            a = float(a)
            b = float(b)
            c = float(c)
            d = (a + b + c) / 3
            # d=format(d, '.2f')#保留两位小数

            cc.append(t)
            cc.append(d)
            cc = np.array(cc)
            dd.append(cc)
        dd = np.array(dd)
        return dd



if __name__ == '__main__':
    # df, df1, df2, df3, df4 = Num_fileread()
    # dd=dataframe_array(df1)
    # print(dd)
    # road_passNum()
#####################################################
    dir='E:\\VISSIM430\\Example\\wyy_excise\\XXX'
    file='xxx.mes'
    df,df1=Num_fileread(dir,file)
    print(df1)
    picture1()








