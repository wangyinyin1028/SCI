import win32com.client as com
import pandas as pd
import os
from matplotlib import pyplot as plt
import numpy as np
import matplotlib as mpl
import pandas as pd
from sklearn.cluster import KMeans
from datetime import datetime
import matplotlib.dates as mdates
from sklearn.cluster import MiniBatchKMeans
from sklearn import metrics
from perimeter_control.vissim.evaluation import Num_fileread,dataframe_array,travaltime


mpl.rcParams['font.sans-serif'] = ['SimHei']  # 使图像正常显示中文标签
mpl.rcParams['axes.unicode_minus'] = False  # 使图像正常显示负号v
class travaltime():
    def __init__(self):
        self.Snum_bus=None
        self.Lnum_bus = None
        self.Rnum_bus = None
        self.S_TRA_bus = None
        self.L_TRA_bus = None
        self.R_TRA_bus = None

    def fileread(self):
        os.chdir('E:\\VISSIM430\\Example\\wyy_excise\\JIAOCHA_grop')
        tem = pd.read_table('jiaochakouqun.rsz', encoding='gbk')
        # print(tem)
        # print(tem[9:].reset_index(drop=True))#截取7行以下的内容
        tem = tem[9:].reset_index(drop=True)
        tem.columns = ['DATA']
        tem1 = pd.DataFrame([var.split(';') for var in tem.DATA])
        # print(tem1)
        tem1.columns = ['NO', 'TravalTime_s', 'Num_bus_s','TravalTime_l', 'Num_bus_l','TravalTime_r', 'Num_bus_r',' ']  # 分号后面也成一列，所以id是空值
        tem1.drop([' '],axis=1,inplace=True)
        # print(tem1)
        return tem1

    def dataframe_array(self,tem1):
        df=tem1
        dd = []
        for i in range(len(df)):
            cc = []
            t=df.iat[i,0]
            a = df.iat[i,1]  # 时间
            b = df.iat[i,3]  # 路段行程时间
            c = df.iat[i,5]  # 路段行程时间

            t = int(t)
            a = float(a)
            b = float(b)
            c = float(c)
            d = (a + b + c) / 3
            # d=format(d, '.2f')#保留两位小数
            # print(type(d))

            cc.append(t)
            cc.append(d)
            cc = np.array(cc)
            dd.append(cc)
        dd = np.array(dd)
        return dd



def kmeans(X,k):
    kme= KMeans(n_clusters=k, init='k-means++', n_init=5, max_iter=50, tol=0.0001,
                    precompute_distances='auto', verbose=0, random_state=None, copy_x=True, n_jobs=1,
                    algorithm='auto').fit(X,sample_weight=None)


    return  kme.labels_,kme.cluster_centers_,kme.inertia_,kme.n_iter_

def lable():
    tem=[]
    for n in labels:
        if n not in tem:
            tem.append(n)
        else:
            pass
    return tem

def dataframe(tem1):
        df=tem1
        dd = []
        for i in range(len(df)):
            cc = []
            t=df.iat[i,0]
            a = df.iat[i,1]  # 时间
            b = df.iat[i,2]  # 路段行程时间
            c = df.iat[i,3]  # 路段行程时间
            t = int(t)
            a = int(a)
            b = float(b)
            c = float(c)
            # d=format(d, '.2f')#保留两位小数
            cc.append(t)
            cc.append(a)
            cc.append(b)
            cc.append(c)
            cc = np.array(cc)
            dd.append(cc)
        dd = np.array(dd)
        return dd

def distan(dd):
    dis2 = []
    for i in range(len(dd)):
        dis = []
        # print("现在是第", i)
        # print(dd[i])
        for j in range(len(dd)):
            # gg = np.sqrt((dd[i][0] - dd[j][0]) ** 2 + (dd[i][1] - dd[j][1]) ** 2 + (dd[i][2] - dd[j][2]) ** 2 + (
            #             dd[i][3] - dd[j][3]) ** 2)
            gg = np.sqrt((dd[i][0] - dd[j][0]) ** 2 + (dd[i][1] - dd[j][1]) ** 2 + (dd[i][2] - dd[j][2]) ** 2 )
            # print(gg)
            dis.append(gg)
        # print(dis)
        # print(len(dis))
        dis2.append(dis)
    # print(dis2)
    # print(dis2[0])
    return dis2
def BA():
    inter = []
    for i in range(len(labels)):
        N = 0
        # print(dd[i])
        # print(labels)
        su = 0
        for j in range(len(labels)):
            if labels[i] == labels[j]:
                N = N + 1
                su = su + dis2[i][j]
            else:
                continue

        Ba = su / N
        # print(su/N)
        inter.append(Ba)
    # print(inter)
    # print(len(inter))
    return inter
def AA():
    lab = lable()#计算分为了几类

    ###计算每一类分别是哪些索引
    kk = []
    for la in lab:
        # print(la)
        temp=[]
        for k in range(len(labels)):
            # print(labels[k])
            if la==labels[k]:
                temp.append(k)
            else:
                pass
        kk.append(temp)
    # print(len(kk))
    # print("dis2 is ",dis2)
    #计算每一个样本的其他类内平均距离最小值
    eee = []
    for a in range(len(kk)):
        # print(kk[a])
        for j in range(len(kk[a])):
            so = 0
            b = kk[a][j]
            # print(b)
            # print(dis2[b])
            ddd = []
            for tt in range(len(kk)):
                if tt != a:
                    # print(a)
                    # print(tt)
                    for ka in kk[tt]:
                        so = so + dis2[b][ka]
                        ss = so / len(kk[tt])
                    ddd.append(ss)
                else:
                    pass
            # print(ddd)
            # print("a,j is ",a,j)
            h = min(ddd)
            eee.append(h)
    return eee
def result(ba,Aa):
    rr = []
    yy = 0
    for i in range(len(dd)):
        Z = Aa[i] - ba[i]
        max = Aa[i]
        if Aa[i] < ba[i]:
            max = ba[i]
        else:
            pass
        sil = Z / max
        rr.append(sil)
    for n in rr:
        yy = yy + n
    result = yy / len(dd)
    return result




if __name__ == '__main__':
    dir='E:\\VISSIM430\\Example\\wyy_excise\\XXX'
    file='xxx.mes'
    df,df1=Num_fileread(dir,file)
    res = []
    k=4
    labels, cluster_centers, inertia_, n_iter_ = kmeans(df1, k)
    dd = dataframe(tem1=df1)
    dis2 = distan(dd)
    ba = BA()
    Aa = AA()
    print(labels)
    print(ba)
    print(Aa)
    result = result(ba, Aa)
    res.append(result)
    print(res)



































    # print(cluster_centers)
    # print(inertia_)
    # print(n_iter_)





    # travaltime=travaltime()
    # tem1=travaltime.fileread()
    # print(tem1.iloc[0:2])
    # dd=travaltime.dataframe_array(tem1)
    # print(dd)
