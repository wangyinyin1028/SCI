import numpy as np
import random
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.collections import PolyCollection
import matplotlib.pyplot as plt
from matplotlib import colors as mcolors
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import openpyxl


p =[]
vehicle={"road1":[],"road2":[],"road3":[],"road4":[],}
def demand():
    for i in range(20):
        p.append(i)
        if  i <= 3:
            a1 = random.uniform(80, i*100+100)
            a2 = random.uniform(80, i*100+130)
            a3 = random.uniform(80, i*100+150)
            a4 = random.uniform(80, i*100+100)
            vehicle["road1"].append(int(a1))
            vehicle["road2"].append(int(a2))
            vehicle["road3"].append(int(a3))
            vehicle["road4"].append(int(a4))
        elif 3 < i <= 7:
            a1 = random.uniform(-500, 500) +(-1800)+ (2410/ 4) * i
            a2 = random.uniform(-400, 600) +(-1800)+ (2410/ 4) * i
            a3 = random.uniform(-400, 700) +(-1800)+ (2410/ 4) * i
            a4 = random.uniform(-500, 500) +(-1800)+ (2410/ 4) * i
            vehicle["road1"].append(int(a1))
            vehicle["road2"].append(int(a2))
            vehicle["road3"].append(int(a3))
            vehicle["road4"].append(int(a4))
        elif 7 < i <= 12:
            a1 = random.uniform(2400, 2700)
            a2 = random.uniform(2500, 2800)
            a3 = random.uniform(2400, 2800)
            a4 = random.uniform(2400, 2700)
            vehicle["road1"].append(int(a1))
            vehicle["road2"].append(int(a2))
            vehicle["road3"].append(int(a3))
            vehicle["road4"].append(int(a4))
        elif 12 < i <= 15:
            a1 = random.uniform(-500, 500) + 8500 + (-2500/ 5) * i
            a2 = random.uniform(-500, 500) + 8500 + (-2500/ 5) * i
            a3 = random.uniform(-500, 500) + 8500 + (-2500/ 5) * i
            a4 = random.uniform(-500, 500) + 8500 + (-2500/ 5) * i
            vehicle["road1"].append(int(a1))
            vehicle["road2"].append(int(a2))
            vehicle["road3"].append(int(a3))
            vehicle["road4"].append(int(a4))
        else:
            a1 = random.uniform(300-i*10, 400)
            a2 = random.uniform(400-i*10, 500)
            a3 = random.uniform(400-i*10, 500)
            a4 = random.uniform(300-i*10, 400)
            vehicle["road1"].append(int(a1))
            vehicle["road2"].append(int(a2))
            vehicle["road3"].append(int(a3))
            vehicle["road4"].append(int(a4))
demand()
print(vehicle["road1"])
def pic():
    plt.figure(figsize=(6, 4))
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    plt.xlabel('time(2min)')
    plt.ylabel('demand(veh/2min)')
    plt.plot(p, vehicle["road1"], label='road1', linewidth=0.5)
    plt.plot(p, vehicle["road2"], label='road2', linewidth=0.5)
    plt.plot(p, vehicle["road3"], label='road3', linewidth=0.5)
    plt.plot(p, vehicle["road4"], label='road4', linewidth=0.5)
    plt.legend(loc='upper right')
    plt.title('低需求')
    plt.show()
pic()
def shujuduqu():
    data = openpyxl.load_workbook(
        r'C:/Users/Jack Bu/Desktop/GO\YanJiuS/代码库/vissim/4road_shuju -_copy.xlsx')
    sheet1 = data.get_sheet_by_name('road1')  # 获取第一个sheet内容
    sheet2 = data.get_sheet_by_name(data.get_sheet_names()[1])  # 获取第一个sheet内容
    sheet3 = data.get_sheet_by_name(data.get_sheet_names()[2])  # 获取第一个sheet内容
    sheet4 = data.get_sheet_by_name(data.get_sheet_names()[3])  # 获取第一个sheet内容
    # sheet5 = data.get_sheet_by_name(data.get_sheet_names()[4])  # 获取第一个sheet内容
    lines = 20 #sheet.max_row  # 获取该sheet中的有效行数,简化版的有效行数不正确
    cols = 3   #sheet.max_column  # 获取该sheet中的有效列数
    print(len(vehicle["road1"]))
    for i in range(0, lines):
        sheet1.cell(row=i+2, column=3, value=vehicle["road1"][i])
        sheet2.cell(row=i+2, column=3, value=vehicle['road2'][i])
        sheet3.cell(row=i+2, column=3, value=vehicle['road3'][i])
        sheet4.cell(row=i+2, column=3, value=vehicle['road4'][i])
        sheet1.cell(row=i + 2, column=4, value=30*vehicle["road1"][i])
        sheet2.cell(row=i + 2, column=4, value=30*vehicle['road2'][i])
        sheet3.cell(row=i + 2, column=4, value=30*vehicle['road3'][i])
        sheet4.cell(row=i + 2, column=4, value=30*vehicle['road4'][i])
        # sheet5.cell(row=i + 2, column=3, value= vehicle['road4'][i]+vehicle['road3'][i]+vehicle['road2'][i]+vehicle['road1'][i])
    data.save("C:/Users/Jack Bu/Desktop/GO\YanJiuS/代码库/vissim/4road_shuju -_copy.xlsx")  # 保存文件
    data.close()
shujuduqu()

