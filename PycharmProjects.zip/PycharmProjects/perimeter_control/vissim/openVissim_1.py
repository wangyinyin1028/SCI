#接入模块
import win32com.client as com  # VISSIM COM
import pythoncom
import pandas as pd
from pandas import DataFrame
import numpy as np
import random
import os
import matplotlib.pyplot as plt
import openpyxl
# 启动程序,加载路网及布局文件
class OpenVissim():  # 继承Problem父类
    def __init__(self, filename,ini):
        self.Vissim = com.Dispatch("Vissim.Vissim")
        dir = filename
        self.Vissim.LoadNet(dir)
        self.Vissim.LoadLayout(ini)
        # Define Simulation Configurations
        graphics = self.Vissim.Graphics
        # graphics.SetAttValue("VISUALIZATION", False)  ## 设为 不可见 提高效率
        self.Sim = self.Vissim.Simulation
        self.Net = self.Vissim.Net
        self.eval = self.Vissim.Evaluation
        print("载入路网完成！")
        self.decisions = self.Net.DesiredSpeedDecisions
        self.datacollections = self.Net.datacollections


    def simulation_parameter(self,totalperiod):
       ##仿真参数设置
       self.Sim.Comment = 'Karlsruhe-Durlach Test11'
       self.Sim.Period = totalperiod  # 返回模拟周期,设置仿真时长

       self.Sim.Speed = 0  # 仿真速度，0表示最大速度，现实中一秒的时间对应的仿真秒数。
       step_time = 1  # Define Step Time
       self.Sim.Resolution = step_time
       self.Sim.ControllerFrequency = 5
       self.Sim.RandomSeed = 13
       self.Sim.RunIndex = 2
       self.eval.SetAttValue("datacollection", True)
       self.eval.SetAttValue("TravelTime", True)
       self.eval.SetAttValue("Delay", True)
       # self.Sim.RunContinuous()  # 仿真开始
       self.Links=self.Net.Links
       self.link1=self.Links.GetLinkByNumber(1)
       self.link5 = self.Links.GetLinkByNumber(5)
       self.connec10037 = self.Links.GetLinkByNumber(10037)

       print(self.link1.name)
       print(self.link5.name)
       print(self.connec10037.name)
       # self.test(self,totalperiod)

       # self.link1.SetAttValue2('LANECLOSED', 1, 1, True)
       # self.link5.SetAttValue2('LANECLOSED', 1, 1, True)
       # self.connec10037.SetAttValue2('LANECLOSED', 1, 1, True)
       self.Sim.Runcontinuous()
    def test(self,totalperiod):
        for i in range(totalperiod):
            if i < 2400:
                self.link1.SetAttValue2('LANECLOSED', 1, 1, True)
                self.link5.SetAttValue2('LANECLOSED', 1, 1, True)
                self.connec10037.SetAttValue2('LANECLOSED', 1, 1, True)
            if 2400 <= i < 6480:
                self.link1.SetAttValue2('LANECLOSED', 1, 1, True)
                self.link5.SetAttValue2('LANECLOSED', 1, 1, True)
                self.connec10037.SetAttValue2('LANECLOSED', 1, 1, True)
            if 6480 <= i < 8400:
                self.link1.SetAttValue2('LANECLOSED', 1, 1, True)
                self.link5.SetAttValue2('LANECLOSED', 1, 1, True)
                self.connec10037.SetAttValue2('LANECLOSED', 1, 1, True)
            if 8400 <= i < 10800:
                self.link1.SetAttValue2('LANECLOSED', 1, 1, True)
                self.link5.SetAttValue2('LANECLOSED', 1, 1, True)
                self.connec10037.SetAttValue2('LANECLOSED', 1, 1, True)
        self.Sim.RunSingleStep()




#######################################################################################################################################

#######################################################################################################################

# VehicleInputs=vnet.VehicleInputs
# print(VehicleInputs.count)
# # VehicleInput1=VehicleInputs.GetVehicleInputByNumber(1)
# # VehicleInput2=VehicleInputs.GetVehicleInputByNumber(2)
# # VehicleInput3=VehicleInputs.GetVehicleInputByNumber(3)
# # VehicleInput4=VehicleInputs.GetVehicleInputByNumber(4)
# datacollections = vnet.DataCollections
# print(datacollections.count)
# list=[]
# for i in range(datacollections.count):
#     datacollection=datacollections.GetDataCollectionByNumber(i)
#     vehicle_num=datacollection.VEHICLEIDS#最后一个完成时间的车辆id

if __name__ == '__main__':

    filename = 'E:\\VISSIM430\\Example\\wyy_excise\\JIAOCHA_grop\\jiaochakouqun.inp'
    ini = 'E:\\VISSIM430\\Example\\wyy_excise\\JIAOCHA_grop\\ jiaochakouqun.ini'
    openVissim = OpenVissim(filename,ini)
    openVissim.simulation_parameter(1800)




