import sklearn
import numpy as np
import matplotlib.pyplot as plt
from sklearn import *
from .evaluation import Num_fileread,dataframe_array,travaltime


#########设置实验数据################

def init_sample():
    centers = [[1, 1], [-1, -1], [1, -1]]
    # 生成数据
    X, label_true = sklearn.datasets.make_blobs(n_samples=150, centers=centers, cluster_std=0.5, random_state=0)
    return X, label_true
##########AP聚类####################
class AP(object):
    """ AP聚类 """

    def __init__(self):
        self.Xn = None
        self.Xn_len = None
        self.R = None
        self.A = None
        self.simi_matrix = None
        self.class_cen = None

    def fit(self, data):
        self.Xn = data
        self.Xn_len = len(data)
        # 初始化R、A矩阵
        self.R = np.zeros((self.Xn_len, self.Xn_len))
        self.A = np.zeros((self.Xn_len, self.Xn_len))
        # 计算相似度
        self.cal_simi()
        # # 输出聚类中心
        self.class_cen = self.cal_cls_center()

    def cal_simi(self):
        """
        计算相似度矩阵
            这个数据集的相似度矩阵，最终是二维数组
            每个数字与所有数字的相似度列表，即矩阵中的一行
            采用负的欧式距离计算相似度
        :return:
        """
        simi = [[-np.sqrt((m[0] - n[0]) ** 2 + (m[1] - n[1]) ** 2) for n in self.Xn] for m in self.Xn]
        # print(simi)
        # print(len(simi))
        # print(len(simi[1]))

        # 设置参考度，即对角线的值，一般为最小值或者中值
        # p = np.min(simi)   ##11个中心
        # p = np.max(simi)  ##14个中心

        p = np.median(simi)  ##5个中心##作用1：计算沿指定轴的中位数，作用2：返回数组元素的中位数
        # print(p)


        for i in range(self.Xn_len):
            simi[i][i] = p
            # print(simi[i][i])

        self.simi_matrix = simi

    def iter_update_R(self, old_r=0, lam=0.5):
        """
        计算吸引度矩阵，即R
               公式1：r(n+1) =s(n)-(s(n)+a(n))-->简化写法，具体参见上图公式
               公式2：r(n+1)=(1-λ)*r(n+1)+λ*r(n)
        迭代更新R矩阵
        :param old_r: 更新前的某个r值
        :param lam: 阻尼系数，用于算法收敛
        :return:
        """
        # 此循环更新R矩阵
        for i in range(self.Xn_len):
            for k in range(self.Xn_len):
                old_r = self.R[i][k]
                # print(old_r)
                if i != k:
                    max1 = self.A[i][0] + self.R[i][0]  ##注意初始值的设置
                    for j in range(self.Xn_len):
                          if j != k:
                            if self.A[i][j] + self.R[i][j] > max1:
                                max1 = self.A[i][j] + self.R[i][j] # 更新后的R[i][k]值
                    self.R[i][k] = self.simi_matrix[i][k] - max1
        #             ##带入阻尼系数重新更新
                    self.R[i][k] = (1 - lam) * self.R[i][k] + lam * old_r
                else:
                     max2 = self.simi_matrix[i][0]  ##注意初始值的设置
                     for j in range(self.Xn_len):
                         if j != k:
                             if self.simi_matrix[i][j] > max2:
                                 max2 = self.simi_matrix[i][j]
                     ##更新后的R[i][k]值
                     self.R[i][k] = self.simi_matrix[i][k] - max2 ##带入阻尼系数重新更新
                     self.R[i][k] = (1 - lam) * self.R[i][k] + lam * old_r

        print("max_r:" + str(np.max(self.R)))

    def iter_update_A(self, old_a=0, lam=0.5):
        """
        迭代更新A矩阵
        :param old_r: 更新前的某个r值
        :param lam: 阻尼系数，用于算法收敛
        :return:
        """
        old_a = 0  ##更新前的某个a值
        lam = 0.8 ##阻尼系数,用于算法收敛
        ##此循环更新A矩阵
        for i in range(self.Xn_len):
            for k in range(self.Xn_len):
                old_a = self.A[i][k]
                if i == k:
                    max3 = self.R[0][k]  ##注意初始值的设置
                    for j in range(self.Xn_len):
                        if j != k:
                            if self.R[j][k] > 0:
                                max3 += self.R[j][k]
                            else:
                                max3 += 0
                    self.A[i][k] = max3
                    # 带入阻尼系数更新A值
                    self.A[i][k] = (1 - lam) * self.A[i][k] + lam * old_a
                else:
                    max4 = self.R[0][k]  # 注意初始值的设置
                    for j in range(self.Xn_len):
                        # 上图公式中的i!=k 的求和部分
                        if j != k and j != i:
                            if self.R[j][k] > 0:
                                max4 += self.R[j][k]
                            else:
                                max4 += 0

                    # 上图公式中的min部分
                    if self.R[k][k] + max4 > 0:
                        self.A[i][k] = 0
                    else:
                        self.A[i][k] = self.R[k][k] + max4

                    # 带入阻尼系数更新A值
                    self.A[i][k] = (1 - lam) * self.A[i][k] + lam * old_a
        print("max_a:" + str(np.max(self.A)))

    def cal_cls_center(self, max_iter=100, curr_iter=0, max_comp=30, curr_comp=0):
        """
        计算聚类中心
            进行聚类，不断迭代直到预设的迭代次数或者判断comp_cnt次后聚类中心不再变化
        :param max_iter: 最大迭代次数
        :param curr_iter: 当前迭代次数
        :param max_comp: 最大比较次数
        :param curr_comp: 当前比较次数
        :return:
        """
        class_cen = []  # 聚类中心列表，存储的是数据点在Xn中的索引
        while True:
            # 计算R矩阵
            self.iter_update_R()
            # 计算A矩阵
            self.iter_update_A()
        #     # 开始计算聚类中心
            for k in range(self.Xn_len):
                 if self.R[k][k] + self.A[k][k] > 0:
                    print(k)
                    if k not in class_cen:
                        print(k)
                        class_cen.append(k)
                    else:
                         curr_comp += 1
            print(class_cen)
            curr_iter += 1
            print('iteration the {}'.format(curr_iter))
            if curr_iter >= max_iter or curr_comp > max_comp:
                 break
        return class_cen

    def c_list(self):
        # 根据聚类中心划分数据
        c_list = []
        for m in self.Xn:
            temp = []
            for j in self.class_cen:
                n = Xn[j]
                d = -np.sqrt((m[0] - n[0]) ** 2 + (m[1] - n[1]) ** 2)
                # print(d)
                temp.append(d)
            # print(temp)
            # 按照是第几个数字作为聚类中心进行分类标识
            c = self.class_cen[temp.index(np.max(temp))]
            # print(c)
            c_list.append(c)
        print(c_list)#每个数据对应的分类结果
        # print(len(c_list))
        return c_list

    def plot(self,class_cen, X, c_list):
        # 画图
        colors = ['red', 'blue', 'black', 'green', 'yellow','orange','brown']
        plt.figure(figsize=(8, 6))
        # plt.xlim([-3, 3])
        # plt.ylim([-3, 3])
        for i in range(len(X)):
            d1 = Xn[i]
            d2 = Xn[c_list[i]]
            c = class_cen.index(c_list[i]) # 这是不对的
            plt.plot([d2[0], d1[0]], [d2[1], d1[1]], color=colors[1], linewidth=1)
            # if i == c_list[i] :
            #     plt.scatter(d1[0],d1[1],color=colors[c],linewidth=3)
            # else :
            #    plt.scatter(d1[0],d1[1],color=colors[c],linewidth=1)
        # plt.savefig('AP 聚类.png')
        # plt.legend()
        plt.show()
def flow_juleiResult():
    ap = AP()  # 产生一个这样的对象，具有数据，数据个数，R吸引度，A归属度，simi_matrix 相似度矩阵，class_cen 聚类中心
    ap.fit(data=Xn)  # 初始化矩阵，计算相似度，
    class_cen = ap.class_cen
    for i in class_cen:
        print(str(i) + ":" + str(Xn[i]))
    c_list = ap.c_list()
    print(class_cen)
    # print(Xn)

    ap.plot(class_cen, Xn, c_list)
    return class_cen,c_list
def Time_julei(class_cen,c_list):
    s=[]
    for i in range(len(class_cen)):
        print(class_cen[0])
        t=0
        for cen in c_list:
          if cen==class_cen[i]:
              t+=1
        s.append(t*4)
    return s






if __name__ == '__main__':
################路段流量聚类###################################
    # 初始化数据
    # Xn, labels_true = init_sample()  # Xn就是datas数据
    df, df1, df2, df3, df4 = Num_fileread()
    dd = dataframe_array(df1)
    Xn = dd

    # flow_juleiResult()#执行聚类过程

###############行程时间聚类#####################################
    travaltime = travaltime()
    tem1 = travaltime.fileread()
    ff = travaltime.dataframe_array(tem1)
    # print(ff)
    # Xn=ff
    class_cen,c_list=flow_juleiResult()#执行聚类过程
    print(class_cen)#聚类中心
    print(c_list)#聚类结果
    s=Time_julei(class_cen,c_list)
    print(s)




