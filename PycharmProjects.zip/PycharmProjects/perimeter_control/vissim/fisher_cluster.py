import win32com.client as com
import pandas as pd
import os
from matplotlib import pyplot as plt
import numpy as np
import matplotlib as mpl
import math
from datetime import datetime
import matplotlib.dates as mdates

mpl.rcParams['font.sans-serif'] = ['SimHei']  # 使图像正常显示中文标签
mpl.rcParams['axes.unicode_minus'] = False  # 使图像正常显示负号

temp = []

# 设置横纵坐标的名称以及对应字体格式
font1 = {
    'weight': 'normal',
    'size': 15,
}

font2 = {
    'weight': 'normal',
    'size': 12,

}
################################数据读取################################################
def Num_fileread(dir,file):
    os.chdir(dir)
    tem = pd.read_table(file, encoding='gbk')
    # print(tem)
    # print(tem[12:].reset_index(drop=True))#截取7行以下的内容
    tem = tem[12:].reset_index(drop=True)
    tem.columns = ['DATA']
    tem1 = pd.DataFrame([var.split(';') for var in tem.DATA])
    tem1.columns = ['Measur', 'from', 'to','greenbus', 'total ', 'social','']#分号后面也成一列，所以id是空值
    # # tem1.drop(['id'],axis=1,inplace=True)
    # print(tem1)
    df=tem1
    df.to_excel('data.xls',sheet_name='data')

    #occup.rate
    df1=df.iloc[(df['Measur']=='1').values,[2,3,4,5]]
    return df,df1
    # df2=df.iloc[(df['Measur']=='2').values,[0,1,2,3,4,5,6]]
    # df3=df.iloc[(df['Measur']=='3').values,[0,1,2,3,4,5,6]]
    # df4=df.iloc[(df['Measur']=='4').values,[0,1,2,3,4,5,6]]
    # return df,df1,df2,df3,df4

def picture1():
    fig=plt.figure(1)
    ax1=fig.add_subplot(111)
    d=df.iloc[(df['Measur']=='1').values,[2]].astype(float)
    # print(type(d))

    ax1.plot(d,df.iloc[(df['Measur']=='1').values,[4]].astype(float), 'o-', label='road1_total')
    ax1.plot(df.iloc[(df['Measur'] == '1').values, [2]].astype(float),df.iloc[(df['Measur'] == '1').values, [3]].astype(float), 'o-', label='road1_bus')
    # ax1.plot(df.iloc[(df['Measur'] == '1').values, [2]].astype(float),df.iloc[(df['Measur'] == '1').values, [6]].astype(float), 'o-', label='road1_bus')
    ax1.plot(df.iloc[(df['Measur'] == '1').values, [2]].astype(float),df.iloc[(df['Measur'] == '1').values, [5]].astype(float), 'o-', label='road1_social')
    ax1.legend()
    plt.grid(True)
    plt.ylabel('车辆数', font1)
    plt.xlabel('Time(10 min)', font1)
    plt.title('路口1通过的车辆数', font1)
    plt.show()

def add_index(df):
    aa=[]
    for i in range(len(df)):
      a=int(df.iat[i, 1])
      b=int(df.iat[i, 3])
      c=a/b
      # print(c)
      c = float(format(c, '.4f'))  # 保留两位小数
      aa.append(c)
    # print(aa)

    df['proportion']=aa
    df.drop(['to'],axis=1,inplace=True)
    return df
########################################
def bb(newdf):
    bb = []
    for i in range(2, len(newdf)):
        d = newdf.iloc[0:i, :].values.tolist()
        bb.append(d)
    return bb
def mean(bb):
    ########生成88*4的矩阵，表示前k+2个样本的各个指标平均值
    mean=[]
    for k in range(len(bb)):
        bus = 0
        total = 0
        social = 0
        rate = 0
        # print(bb[k])
        for j in range(len(bb[k])):
            tem = []
            bus=bus+ int(bb[k][j][0])
            total=total+int(bb[k][j][1])
            social=social+int(bb[k][j][2])
            rate=rate+float(bb[k][j][3])
        num=k+2
        aaa=float(bus/num)
        bbb = float(total / num)
        ccc = float(social / num)
        ddd = float(rate / num)
        tem.append(aaa)
        tem.append(bbb)
        tem.append(ccc)
        tem.append(ddd)
        mean.append(tem)
    return mean
def tem(part):
    if len(part)==1:
        d=0
    else:
        dia = 0
        for i in range(len(part)):
           dia1=(int(part[i][0])-mean[i][0])**2+(int(part[i][1]) - mean[i][1]) ** 2+(int(part[i][2]) - mean[i][2]) ** 2+(int(part[i][3]) - mean[i][3]) ** 2
           dia=dia+dia1




#########################################
def dataframe_array(tem1):
    df=tem1
    dd = []
    for i in range(len(df)):
        cc = []
        t=df.iat[i,0]
        a = df.iat[i,1]  # 时间
        b = df.iat[i,2]  # 路段行程时间
        c = df.iat[i,3]  # 路段行程时间

        t = int(t)
        a = int(a)
        b = int(b)
        c = float(c)

            # d=format(d, '.2f')#保留两位小数
            # print(type(d))

        cc.append(t)
        cc.append(a)
        cc.append(b)
        cc.append(c)
        cc = np.array(cc)
        dd.append(cc)
    dd = np.array(dd)
    return dd





def spilt_numpy_array(data):  # data是list
    for i in range(1, len(data)):

        new_single_res = [data[:i], data[i:]]  # 单次循环
        # print("new_single_res is ", new_single_res)
        # print("data[i:] is ", data[i:])
        # print("new_single_res is ", new_single_res)

        if i == 1:
            new_res = [new_single_res]
        else:
            new_res.append(new_single_res)
    # print(new_res)

    return new_res

total=[]
def recursive_fun(situation, num_of_now=1, num_of_categories=8):

    if num_of_now <= num_of_categories:

        # print("Now it is the %d situation, sum of the situations is %d " % (num_of_now, num_of_categories))
        # print("len of the situation is ", len(situation))
        # print("The situation is ", situation)
        total.append(situation)
        for i in range(len(situation)):
            if len(situation[i]) == 1:
                # print("i is %d, len(situation[i]) == 1," % i, "len of situation[i] is ", situation[i])
                pass
            else:
                # print("situation[:i] is ", len(situation[:i]))
                # print("i is %d, len of situation[i] is " % i, len(situation[i]))
                split_data = spilt_numpy_array(situation[i])
                # print("len(split_data) is ", len(split_data))
                # print("situation[(i+1):] is ", len(situation[(i+1):]))

                for x in split_data:
                    # print("i is %d " % i, "x is ", len(x))
                    # print("situation[:i] is ", len(situation[:i]))
                    # print("situation[(i+1):] is ", len(situation[(i+1):]))

                    situation_next = situation[:i] + x + situation[(i+1):]
                    # print("situation_next is ", len(situation_next))
                    recursive_fun(situation=situation_next, num_of_now=num_of_now+1, num_of_categories=num_of_categories)
    else:
        pass

def recursive_fun2(situation, num_of_now=1, num_of_categories=8):
    global temp
    if num_of_now <= num_of_categories:
        temp.append(situation)
        # print("Now it is the %d situation, sum of the situations is %d " % (num_of_now, num_of_categories))
        # print("len of the situation is ", len(situation))
        # print("The situation is ", situation)

        for i in range(len(situation)):

            if len(situation[i]) == 1:
                # print("i is %d, len(situation[i]) == 1," % i, "len of situation[i] is ", situation[i])
                pass
            else:
                # print("situation[:i] is ", len(situation[:i]))
                # print("i is %d, len of situation[i] is " % i, len(situation[i]))
                split_data = spilt_numpy_array(situation[i])
                # print("len(split_data) is ", len(split_data))
                # print("situation[(i+1):] is ", len(situation[(i+1):]))

                for x in split_data:
                    # print(x)
                    # print("i is %d " % i, "x is ", len(x))
                    # print("situation[:i] is ", len(situation[:i]))
                    # print("situation[(i+1):] is ", len(situation[(i+1):]))

                    situation_next = situation[:i] + x + situation[(i+1):]
                    # print("situation_next is ", len(situation_next))
                    recursive_fun2(situation=situation_next, num_of_now=num_of_now+1, num_of_categories=num_of_categories)
    else:
        pass
    # print(len(temp))

def delet_repeat(sample):
    tem=[]
    tem.append(sample[0])
    # print(tem)
    for y in sample:
         # print('y is ',y)
         tem2 = []
         if y not in tem:
              tem.append(y)
    return tem
def iterate(x_sample,lenght):
    global temp
    # x_sample=two_sample
    k=len(x_sample[0])
    print(k)
    for i in range(len(x_sample)):
        temp = []
        # print(temp)
        recursive_fun2(x_sample[i], num_of_now=k, num_of_categories=k+1)
        temp = temp[1:]
        # print('len(two_three)', len(temp))
        for z in temp:
            xx_tem.append(z)
    xxx_tem = delet_repeat(sample=xx_tem)
    # print('len(three_sample)', len(xxx_tem))
    m=math.factorial(lenght) // (math.factorial(k) * math.factorial(lenght - k))
    return xxx_tem[(len(xxx_tem)-m):]

def Diameter(x_sample):
    for m in x_sample:
        for i in range(len(m)):
            print(m[i])
            print(len(m[i]))
            if len(m[i])==1:
                pass
            else:
                pass
def mea(part):
    if len(part)==1:
        bus=int(part[0][0])
        total = int(part[0][1])
        social = int(part[0][2])
        rate = float(part[0][3])
    else:
        aa,bb,cc,ddd = 0,0,0,0
        for k in range(len(part)):
            aa = aa + int(part[k][0])
            bb = bb + int(part[k][1])
            cc = cc + int(part[k][2])
            ddd = ddd + float(part[k][3])
        num = len(part)
        bus = float(aa / num)
        total = float(bb / num)
        social = float(cc / num)
        rate = float(ddd / num)
    return bus,total,social,rate

def diameter(data):
    ss=0
    bus, total, social, rate = mea(part=data)
    for j in range(len(data)):
        tt = (data[j][0] - bus) ** 2 + (data[j][1] -total) ** 2 + (data[j][2] - social) ** 2 + (data[j][3] - rate) ** 2
        ss = ss + tt
    return ss

if __name__ == '__main__':

####################数据读取#################################
    dir='E:\\VISSIM430\\Example\\wyy_excise\\XXX'
    file='xxx5.mes'
    df,df1=Num_fileread(dir,file)
    # picture1()
# print(df1)
newdf=add_index(df=df1)
dd=dataframe_array(tem1=newdf)
# print(dd) # type(dd) = numpy.ndarray
dd = dd.tolist()
lenght=(len(dd)-1)
# print('插孔数',lenght)
print([dd])
# print("len of [dd] is ", len([dd]))
# print(spilt_numpy_array([dd][0]))
recursive_fun([dd], num_of_now=1, num_of_categories=2)
two_sample=[]
xx_tem=[]
for l in total:
    if len(l)==2:
        # two+=1
        two_sample.append(l)

print("two_sample has ",len(two_sample))
print("two_sample is ",two_sample)
# print("two_sample[0][0] is ",two_sample[0][0])
print("two_sample[0][0] is ",two_sample[0][1])
# 计算某一个类的平均值
bus,total,social,rate=mea(part=two_sample[0][1])
print(bus)
print(total)
print(social)
print(rate)
ss=diameter(data=two_sample[0][1])




# print(ss)

# Diameter(x_sample=two_sample)




# three_sample=iterate(two_sample,lenght)
# print('3类的所有情况',len(three_sample))
# four_sample=iterate(three_sample,lenght)
# print('4类的所有情况',len(four_sample))
# five_sample=iterate(four_sample,lenght)
# print('5类的所有情况',len(five_sample))
# six_sample=iterate(five_sample,lenght)
# print('6类的所有情况',len(six_sample))








# seven_sample=iterate(six_sample,lenght)
# print('7类的所有情况',len(seven_sample))
# eight_sample=iterate(seven_sample,lenght)
# print('8类的所有情况',len(eight_sample))
# nine_sample=iterate(eight_sample,lenght)
# print('9类的所有情况',len(nine_sample))
# #
# ten_sample=iterate(nine_sample,lenght)
# print('10类的所有情况',len(ten_sample))
# #
# eleven_sample=iterate(ten_sample,lenght)
# print('11类的所有情况',len(eleven_sample))
# #
# twelve_sample=iterate(eleven_sample,lenght)
# print('12类的所有情况',len(twelve_sample))





