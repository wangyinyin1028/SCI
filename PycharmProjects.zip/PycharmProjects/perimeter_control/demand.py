import numpy as np
import random
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.collections import PolyCollection
import matplotlib.pyplot as plt
from matplotlib import colors as mcolors
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

dc = {1_1: [], 1_2: [], 2_1: [], 2_2: []}
db = {1_1: [], 1_2: [], 2_1: [], 2_2: []}
d = {1_1: [], 1_2: [], 2_1: [], 2_2: []}
x =[]

############# 产生低需求，控制300步，一步三次需求 #############
def lowdemand():
        for i  in range(1700):
          if i<=45:
              a1 = random.uniform(0, 0.1) + (0.2 / 45) * i
              a2 = random.uniform(0, 0.1) + (0.2 / 45) * i
              a3 = random.uniform(0, 0.1) + (0.4/ 45) * i
              a4 = random.uniform(0, 0.1) + (0.2/ 45) * i
              dc[1_1].append(a1)
              dc[1_2].append(a2)
              dc[2_1].append(a3)
              dc[2_2].append(a4)
          elif 45<i<=105:
              a1 = random.uniform(0.2, 0.3)
              a2 = random.uniform(0.2, 0.3)
              a3 = random.uniform(0.4, 0.45)
              a4 = random.uniform(0.2, 0.3)
              dc[1_1].append(a1)
              dc[1_2].append(a2)
              dc[2_1].append(a3)
              dc[2_2].append(a4)
          elif 105 < i <= 150:

              a1 = random.uniform(0, 0.1)+0.66+(-0.2/45)*i
              a2 = random.uniform(0, 0.1)+0.66+(-0.2/45)*i
              a3 = random.uniform(0, 0.1)+1.3+(-0.4/45)*i
              a4 = random.uniform(0, 0.1)+0.66+(-0.2/45)*i
              dc[1_1].append(a1)
              dc[1_2].append(a2)
              dc[2_1].append(a3)
              dc[2_2].append(a4)
          else:
              dc[1_1].append(0.000001)
              dc[1_2].append(0.000001)
              dc[2_1].append(0.000001)
              dc[2_2].append(0.000001)
        for i in range(1700):
         if i < 150:
            db[1_1].append(10/120)
            db[1_2].append(10/120)
            db[2_1].append(10/120)
            db[2_2].append(10/120)                     # 以上需求全部暂定，需要改动
         else:
             db[1_1].append(0)
             db[1_2].append(0)
             db[2_1].append(0)
             db[2_2].append(0)
        for i in range(1700):
            x.append(i)
            d[1_1].append(db[1_1][i]+dc[1_1][i])
            d[1_2].append(db[1_2][i]+dc[1_2][i])
            d[2_1].append(db[2_1][i]+dc[2_1][i])
            d[2_2].append(db[2_2][i]+dc[2_2][i])
        picture_lowdemand()
        return d
def picture_lowdemand():
    plt.figure(figsize=(6,4))
    plt.rcParams['font.sans-serif']=['SimHei']
    plt.rcParams['axes.unicode_minus']=False
    plt.xlabel('time(2min)')
    plt.ylabel('demand(veh/sec)')
    plt.plot(x,d[1_1],label='d11',linewidth=0.5)
    plt.plot(x,d[1_2],label='d12',linewidth=0.5)
    plt.plot(x,d[2_1],label='d21',linewidth=0.5)
    plt.plot(x,d[2_2],label='d22',linewidth=0.5)
    plt.legend(loc='upper right')
    plt.title('低需求')
    plt.show()
# ############## 产生高需求，控制300步，一步三次需求 #############
def highdemand():
 for i  in range(1700):
   if i<=45:
       a1 = random.uniform(0, 0.1)+(0.3/45)*i
       a2 = random.uniform(0, 0.1)+(0.3/45)*i
       a3 = random.uniform(0, 0.1)+(0.3/45)*i
       a4 = random.uniform(0, 0.1)+(0.3/45)*i
       dc[1_1].append(a1)
       dc[1_2].append(a2)
       dc[2_1].append(a3)
       dc[2_2].append(a4)
   elif 45<i<=105:
     a1 = random.uniform(0.2,0.3)
     a2 = random.uniform(0.2,0.3)
     a3 = random.uniform(0.2,0.3)
     a4 = random.uniform(0.2,0.3)
     dc[1_1].append(a1)
     dc[1_2].append(a2)
     dc[2_1].append(a3)
     dc[2_2].append(a4)
   elif 105 < i <= 150:
       a1 = random.uniform(1,1.2)+(-0.3/45)*i
       a2 = random.uniform(1,1.2)+(-0.3/45)*i
       a3 = random.uniform(1,1.2)+(-0.3/45)*i
       a4 = random.uniform(1,1.2)+(-0.3/45)*i
       dc[1_1].append(a1)
       dc[1_2].append(a2)
       dc[2_1].append(a3)
       dc[2_2].append(a4)
   else:
       dc[1_1].append(0.01)
       dc[1_2].append(0.01)
       dc[2_1].append(0.01)
       dc[2_2].append(0.01)

 for i in range(1700):
  if i < 150:
      db[1_1].append(10 / 120)
      db[1_2].append(10/120)
      db[2_1].append(10/120)
      db[2_2].append(10/120)                     # 以上需求全部暂定，需要改动
  else:
      db[1_1].append(0)
      db[1_2].append(0)
      db[2_1].append(0)
      db[2_2].append(0)

 for i in range(1700):
     x.append(i)
     d[1_1].append(db[1_1][i]+dc[1_1][i])
     d[1_2].append(db[1_2][i]+dc[1_2][i])
     d[2_1].append(db[2_1][i]+dc[2_1][i])
     d[2_2].append(db[2_2][i]+dc[2_2][i])
 print(d)
def picture_highdemand():
 plt.figure(figsize=(6,4))
 plt.rcParams['font.sans-serif']=['SimHei']
 plt.rcParams['axes.unicode_minus']=False
 plt.xlabel('time(2min)')
 plt.ylabel('demand(veh/sec)')
 plt.plot(x,d[1_1],label='d11',linewidth=0.5)
 plt.plot(x,d[1_2],label='d12',linewidth=0.5)
 plt.plot(x,d[2_1],label='d21',linewidth=0.5)
 plt.plot(x,d[2_2],label='d22',linewidth=0.5)
 plt.legend(loc='upper left')
 plt.title('高需求')
 plt.show()
# ############## 试验低 #############
def lowDemand_test():
 for i  in range(1700):
   if i<=45:
       dc[1_1].append(0.01)
       dc[1_2].append(0.01)
       dc[2_1].append(0.01)
       dc[2_2].append(0.01)
   elif 45<i<=105:
     dc[1_1].append(0.05)
     dc[1_2].append(0.05)
     dc[2_1].append(0.05)
     dc[2_2].append(0.05)
   elif 105 < i <= 150:
       dc[1_1].append(0.00001)
       dc[1_2].append(0.00001)
       dc[2_1].append(0.00001)
       dc[2_2].append(0.00001)
   else:
       dc[1_1].append(0)
       dc[1_2].append(0)
       dc[2_1].append(0)
       dc[2_2].append(0)

 for i in range(1700):
  if i < 150:
      db[1_1].append(10 / 120)
      db[1_2].append(10/120)
      db[2_1].append(10/120)
      db[2_2].append(10/120)                     # 以上需求全部暂定，需要改动
  else:
      db[1_1].append(0)
      db[1_2].append(0)
      db[2_1].append(0)
      db[2_2].append(0)

 for i in range(1700):
     x.append(i)
     d[1_1].append(db[1_1][i]+dc[1_1][i])
     d[1_2].append(db[1_2][i]+dc[1_2][i])
     d[2_1].append(db[2_1][i]+dc[2_1][i])
     d[2_2].append(db[2_2][i]+dc[2_2][i])
############## 试验高 #############
def hignDemand_test():
    for i  in range(1700):
      if i<=45:
          dc[1_1].append(0.01)
          dc[1_2].append(0.01)
          dc[2_1].append(0.01)
          dc[2_2].append(0.01)
      elif 45<i<=105:
        dc[1_1].append(0.071)
        dc[1_2].append(0.071)
        dc[2_1].append(0.071)
        dc[2_2].append(0.071)
      elif 105 < i <= 150:
          dc[1_1].append(0.02)
          dc[1_2].append(0.02)
          dc[2_1].append(0.02)
          dc[2_2].append(0.02)
      else:
          dc[1_1].append(0)
          dc[1_2].append(0)
          dc[2_1].append(0)
          dc[2_2].append(0)

    for i in range(1700):
     if i < 150:
         db[1_1].append(10 / 120)
         db[1_2].append(10/120)
         db[2_1].append(10/120)
         db[2_2].append(10/120)                     # 以上需求全部暂定，需要改动
     else:
         db[1_1].append(0)
         db[1_2].append(0)
         db[2_1].append(0)
         db[2_2].append(0)

    for i in range(1700):
        x.append(i)
        d[1_1].append(db[1_1][i]+dc[1_1][i])
        d[1_2].append(db[1_2][i]+dc[1_2][i])
        d[2_1].append(db[2_1][i]+dc[2_1][i])
        d[2_2].append(db[2_2][i]+dc[2_2][i])
###############################################################################
def GouZao():
    verts = []
    zs = [1, 3, 5, 7]  # 四个图形的间距
    for z in zs:
        if z==1:
            tem1=[]
            for i in range(150):
                d[1_1][0], d[1_1][149] = 0, 0
                temp=[]
                xs=i
                ys=d[1_1][i]

                temp=[xs,ys]
                tem1.append(temp)
            verts.append(tem1)
        if z==3:
            tem2=[]
            for i in range(150):
                d[1_2][0], d[1_2][149] = 0, 0
                temp=[]
                xs=i
                ys=d[1_2][i]
                temp=[xs,ys]
                tem2.append(temp)
            verts.append(tem2)
        if z==5:
            tem3=[]
            for i in range(150):
                d[2_1][0], d[2_1][149] = 0, 0
                temp=[]
                xs=i
                ys=d[2_1][i]
                temp=[xs,ys]
                tem3.append(temp)
            verts.append(tem3)

        if z==7:
            tem4=[]
            for i in range(150):
                d[2_2][0], d[2_2][149]=0, 0
                temp=[]
                xs=i
                ys=d[2_2][i]
                temp=[xs,ys]
                tem4.append(temp)
            verts.append(tem4)
    return verts,zs
    # print(len(verts))
    # print(verts)
    # print(len(verts[1]))
def lowdemand_3d():
    lowdemand()
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    def cc(arg):
        return mcolors.to_rgba(arg, alpha=0.7)

    xs = np.arange(0, 150, 1)  # 四个图形的
    GouZao()
    verts, zs = GouZao()
    print(verts[1][60])
    poly = PolyCollection(verts, facecolors=[cc('r'), cc('g'), cc('b'),
                                             cc('y')])  # 设置每个图的格式
    poly.set_alpha(1)
    ax.add_collection3d(poly, zs=zs, zdir='y')
    ax.set_xlabel('Time(2min)')
    ax.set_xlim3d(0, 150)
    ax.set_ylabel('Y')
    ax.set_ylim3d(0, 8)
    ax.set_zlabel('demand(veh/sec')
    ax.set_zlim3d(0, 0.6)

    ax.elev = 10
    ax.azim = 145  # 视角改变

    plt.show()
def highdemnad_3d():
    highdemand()
    fig = plt.figure()
    ax = fig.gca(projection='3d')

    def cc(arg):
        return mcolors.to_rgba(arg, alpha=0.7)

    xs = np.arange(0, 150, 1)  # 四个图形的
    GouZao()
    verts, zs = GouZao()
    print(verts[1][60])
    poly = PolyCollection(verts, facecolors=[cc('r'), cc('g'), cc('b'),
                                             cc('y')])  # 设置每个图的格式
    poly.set_alpha(1)
    ax.add_collection3d(poly, zs=zs, zdir='y')
    ax.set_xlabel('Time(2min)')
    ax.set_xlim3d(0, 150)
    ax.set_ylabel('Y')
    ax.set_ylim3d(0, 8)
    ax.set_zlabel('demand(veh/sec')
    ax.set_zlim3d(0, 0.6)

    ax.elev = 10
    ax.azim = 145  # 视角改变

    plt.show()


#################################################################################
# if __name__ == '__main__':
    # hignDemand_test()
    # lowdemand_3d()
d1= lowdemand()
# picture_lowdemand(d1)
# highdemnad_3d()
print(d1)





