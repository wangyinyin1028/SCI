import numpy as np
import  math
import random
import matplotlib.pyplot as plt
from demand import d1,db,dc
d=d1

## MFD模型参数
N1 = 100
n11 = 80
n12 = 50
N2 = 160
n21 = 50
n22 = 40
N1_C = 2396
N2_C = 1338
N1_JAM = 5000
N2_JAM = 2500
l = [31.04, 21.415]
l1 =[3.1,2.9,3.0,3.3]
l2 =[1.9,2.1,2.0,1.3]
t_c = 360  # 控制时间 单位为秒
C = 120
t_s = 300  # 控制步数
G1 = -3E-08* pow(N1, 2) + 6E-04 *N1 + 0.0183
G2 = -6E-08*pow(N2, 2) + 8E-04 *N2  + 0.0399
m11 = (n11 / N1) * G1
m12 = (n12 / N1) * G1
m22 = (n22 / N2) * G2
m21 = (n21 / N1) * G2


#####################################first_layer参数#######################################
n_p = {1_1: np.ones(900), 1_2: np.ones(900), 2_1: np.ones(900), 2_2: np.ones(900)}
N_p = {'区域1': np.zeros(900), '区域2': np.zeros(900)}
m = {1_1: np.zeros(900), 1_2: np.zeros(900), 2_1: np.zeros(900), 2_2: np.zeros(900)}
G = {'区域1': np.zeros(900), '区域2': np.zeros(900)}
vc = {'区域1': np.zeros(900), '区域2': np.zeros(900)}
#############################  first_layer参数  #################################################
def init():
    n_p[1_1][0] = 80
    n_p[1_2][0] = 50
    n_p[2_1][0] = 50
    n_p[2_2][0] = 40
    N_p['区域1'][0] = n_p[1_1][0] + n_p[1_2][0]
    N_p['区域2'][0] = n_p[2_1][0] + n_p[2_2][0]
    G['区域1'][0] = -3E-09 * pow(N_p['区域1'][0], 2) + 6E-05 * (N_p['区域1'][0]) + 0.0183
    G['区域2'][0] = -6E-09 * pow(N_p['区域2'][0], 2) + 8E-05 * (N_p['区域2'][0]) + 0.0399
    m[1_1][0] = (n_p[1_1][0] / N_p['区域1'][0]) * G['区域1'][0]
    m[1_2][0] = (n_p[1_2][0] / N_p['区域1'][0]) * G['区域1'][0]
    m[2_1][0] = (n_p[1_1][0] / N_p['区域2'][0]) * G['区域2'][0]
    m[2_2][0] = (n_p[1_2][0] / N_p['区域2'][0]) * G['区域2'][0]
    b = 1
    a = 0
    e = 0.001
    pop_size = 100
    return b,a,e,pop_size
def delta():
    for i in range(1, 50):
        if (b - a) / e < 2 ** i:
            break
        else:
            i = i + 1
        m = i
        chrom_length = 2 * m
    return chrom_length
############ 通过geneEncoding函数生成简单随机序列的函数
def geneEncoding(pop_size, chrom_length):
    pop = []
    for i in range(pop_size):
        temp = []
        for j in range(chrom_length):
            temp.append(random.randint(0, 1))
        pop.append(temp)
    return (pop)
def decodechrom(pop, chrom_length):  # 通过 decodechrom函数将二进制转化为十进制
    temp = []
    for i in range(pop_size):
        tem = []
        t = 0
        for j in range(2):
            for k in range(int(chrom_length / 2)):
                t += pop[i][j * 10 + k] * (math.pow(2, k))
            u = t / (math.pow(2, chrom_length / (2)) - 1)
            if u<0.1:
                u=0.1
            tem.append(u)
            t = 0
        temp.append(tem)
    return temp
def calobjValue(pop, chrom_length,k):
    obj_value = []
    u = decodechrom(pop, chrom_length)
    for i in range(len(u)):
        # print(u[i])
        f1 = 0
        f2 = 0
        f3=0
        n_p[1_1][k + 1] = n_p[1_1][k]+ C * (d[1_1][k+1]) + t_c * (u[i][1] * m[2_1][k] - m[1_1][k])  # 调用decodechrom(pop,chrom_length)后u的前20个值是1—2，后20个值是2—1
        n_p[1_2][k + 1] = n_p[1_2][k] + C * (d[1_2][k]) - t_c * (u[i][0] * m[1_2][k])
        n_p[2_2][k + 1] = n_p[2_2][k] + C * (d[2_2][k]) + t_c * (u[i][0] * m[1_2][k] - m[2_2][k])
        n_p[2_1][k + 1] = n_p[2_1][k] + C * (d[2_1][k]) - t_c * (u[i][1] * m[2_1][k])

        if n_p[1_1][k + 1] < 0:
            n_p[1_1][k + 1] = 0
        if n_p[1_2][k + 1] < 0:
            n_p[1_2][k + 1] = 0
        if n_p[2_2][k + 1] < 0:
            n_p[2_2][k + 1] = 0
        if n_p[2_1][k + 1] < 0:
            n_p[2_1][k + 1] = 0

        print(n_p[2_1][k + 1])
        print(n_p[2_2][k + 1])
        N_p['区域1'][k + 1] = n_p[1_1][k + 1] + n_p[1_2][k + 1]
        N_p['区域2'][k + 1] = n_p[2_1][k + 1] + n_p[2_2][k + 1]
        print("区域1=", +N_p['区域1'][k + 1])
        print("区域2=",+N_p['区域2'][k + 1])


        G['区域2'][k + 1] = -1E-07 * pow(N_p['区域2'][k + 1], 2) +4E-04 * (N_p['区域2'][k + 1]) + 0.022
        G['区域1'][k + 1] = -2E-07 * pow(N_p['区域1'][k + 1], 2) + 5E-04 * (N_p['区域1'][k + 1]) + 0.0478
        print("G区域2=",+G['区域2'][k + 1])
        # G1 = -3E-08 * pow(i, 2) + 6E-04 * i + 0.0183
        # y = -4E-08 * pow(i, 2) + 6E-04 * (i) + 0.0399

        if G['区域1'][k + 1] < 0:
            G['区域1'][k + 1] = 0
        if G['区域2'][k + 1] < 0:
            G['区域2'][k + 1] = 0
        if N_p['区域1'][k + 1] == 0 or G['区域1'][k + 1] == 0:
            m[1_1][k + 1] = 0
            m[1_2][k + 1] = 0
        else:
            m[1_1][k + 1] = (n_p[1_1][k + 1] / N_p['区域1'][k + 1]) * G['区域1'][k + 1]
            m[1_2][k + 1] = (n_p[1_2][k + 1] / N_p['区域1'][k + 1]) * G['区域1'][k + 1]
        if N_p['区域2'][k + 1] == 0 or G['区域2'][k + 1] == 0:
            m[2_1][k + 1] = 0
            m[2_2][k + 1] = 0
        else:
            m[2_1][k + 1] = (n_p[2_1][k + 1] / N_p['区域2'][k + 1]) * G['区域2'][k + 1]
            m[2_2][k + 1] = (n_p[2_2][k + 1] / N_p['区域2'][k + 1]) * G['区域2'][k + 1]
        if N_p['区域1'][k + 1] > 0:
            vc['区域1'][k + 1] = G['区域1'][k + 1] / (N_p['区域1'][k + 1] / (l[0] * 1000))
        else:
            vc['区域1'][k + 1] = 16.7  # 限速60
        if N_p['区域1'][k + 1] > 0:
            vc['区域2'][k + 1] = G['区域2'][k + 1] / (N_p['区域2'][k + 1] / (l[1] * 1000))
        else:
            vc['区域2'][k + 1] = 16.7  # 限速60

        if vc['区域1'][k + 1] < 0:
            vc['区域1'][k + 1] = 0
        # if vc['区域1'][k + 1] > 16.7:
        #     vc['区域1'][k + 1] = 16.7
        if vc['区域2'][k + 1] < 0:
            vc['区域2'][k + 1] = 0
        # if vc['区域1'][k + 1] > 16.7:
        #     vc['区域1'][k + 1] = 16.7

        f1 += N_p['区域1'][k + 1] + N_p['区域2'][k + 1]

        f2 += m[2_2][k + 1] + m[1_1][k + 1]  # 由于需求设置使得G为0导致m为0，故f2为0，存在问题（可能是G的函数存在问题）
        f3 += G['区域1'][k + 1]+G['区域2'][k + 1]
        # print(f2)
        f = (f2 / f1)*1000
        # print(f2)
        obj_value.append(f)
    return obj_value

        ###########去除obj_value中的负值与无穷值
def calfiValue(obj_value):
            fit_value = []
            # c_min = 0
            # (m, obj_value) = calobjValue(pop, chrom_length)

            for i in range(len(obj_value)):
                if (obj_value[i] > 0 and obj_value[i] < float('inf')):
                    temp = obj_value[i]
                else:
                    temp = 0.0
                fit_value.append(temp)
            return fit_value
def sum(fit_value):
    total = 0
    for i in range(len(fit_value)):
        total += fit_value[i]
    return total
def fitness1(obj_value):
    fit_value = calfiValue(obj_value)
    # print(fit_value)
    total = sum(fit_value)
    fitness=[]
    for i in range(len(fit_value)):
        fit=fit_value[i]/total
        fitness.append(fit)
    return fitness


def select(pop_size, fitness,pop):
    pop1=[]# nature selection wrt pop's fitness
    idx = np.random.choice(np.arange(pop_size), size=pop_size, replace=True,p=fitness)
    for i in idx:
        pop1.append(pop[i])
    return pop1


    #pop_size=100,重新组成100个，但有一些重复，每个数字被选中的概率是适应度

    #     # numpy.random.choice(a, size=None, replace=True, p=None)
    # 从a(只要是ndarray都可以，但必须是一维的)中随机抽取数字，并组成指定大小(size)的数组
    # replace:True表示可以取相同数字，False表示不可以取相同数字
    # 数组p：与数组a相对应，表示取数组a中每个元素的概率，默认为选取每个元素的概率相同。
def crossover(parent, pop):     # mating process (genes crossover)
    if np.random.rand() < CROSS_RATE:
        i = np.random.randint(0, pop_size)
        # print(i)
        # print(pop[i])
        cpoint = random.randint(0, chrom_length-1)
        # print(cpoint)
        temp1 = []
        # print(parent)
        temp1.extend(parent[0:cpoint])
        temp1.extend(pop[i][cpoint:len(pop[i])])
        parent=temp1
    return parent
def mutate(child):
    for point in range(chrom_length):
        b=np.random.rand()
        if b< MUTATION_RATE:
            if child[point] == 1:
                child[point] = 0
            if child[point] == 0:
                child[point] = 1
    return child

def best(pop, fit_value):
        # print(fit_value)
        max1=max(fit_value)
        # print(max1)
        # print(fit_value.index(max1))
        best_fit =max1
        best_individual =pop[fit_value.index(max1)]

        return best_individual, best_fit

def b2d(best_individual):
    # print(best_individual)
    # print(len(best_individual))
    u_best = []
    t = 0
    for i in range(2):
        for k in range(10):
            t += best_individual[i * 10 + k] * (math.pow(2, k))
        u = t / (math.pow(2, chrom_length / 2 ) - 1)
        # print(u)
        u_best.append(u)
        t = 0
    a = [u_best[0], u_best[1]]
    return a

def result():
    pop = geneEncoding(pop_size, chrom_length)
    for i in range(generation):
        obj_value = calobjValue(pop, chrom_length, k)
        fitness = fitness1(obj_value)
        pop = select(pop_size, fitness, pop)
        pop_copy = pop.copy()
        for parent in pop:
            child = crossover(parent, pop_copy)
            child = mutate(child)
            parent[:] = child
    # print(pop)
    obj_value = calobjValue(pop, chrom_length, k)
    fit_value = calfiValue(obj_value)
    best_individual, best_fit = best(pop, fit_value)
    u = b2d(best_individual)
    return u
def leiji_veh(u):
        NP1=[]
        NP2=[]
        n_p[1_1][k + 1] = n_p[1_1][k] + C * (d[1_1][k + 1]) + t_c * (u[1] * m[2_1][k] - m[1_1][k])  # 调用decodechrom(pop,chrom_length)后u的前20个值是1—2，后20个值是2—1
        n_p[1_2][k + 1] = n_p[1_2][k] + C * (d[1_2][k]) - t_c * (u[0] * m[1_2][k])
        n_p[2_2][k + 1] = n_p[2_2][k] + C * (d[2_2][k]) + t_c * (u[0] * m[1_2][k] - m[2_2][k])
        n_p[2_1][k + 1] = n_p[2_1][k] + C * (d[2_1][k]) - t_c * (u[1] * m[2_1][k])
        if n_p[1_1][k + 1] < 0:
            n_p[1_1][k + 1] = 0
        if n_p[1_2][k + 1] < 0:
            n_p[1_2][k + 1] = 0
        if n_p[2_2][k + 1] < 0:
            n_p[2_2][k + 1] = 0
        if n_p[2_1][k + 1] < 0:
            n_p[2_1][k + 1] = 0
        N_p['区域1'][k + 1] = n_p[1_1][k + 1] + n_p[1_2][k + 1]
        N_p['区域2'][k + 1] = n_p[2_1][k + 1] + n_p[2_2][k + 1]

        NP1.append(N_p['区域1'][k + 1])
        NP2.append(N_p['区域2'][k + 1])

        return NP1,NP2





if __name__=="__main__":
 b,a,e,pop_size=init()
 CROSS_RATE=0.8
 MUTATION_RATE = 0.03
 generation=5
#########数据初始化###########################################
chrom_length = delta()
# print(pop)
control_u12=[]
control_u21=[]
leiji_veh1=[]
leiji_veh2=[]
x=[]
for k in range(160):
    print(k)
    print()
    x.append(k+1)
    # u=result()
    u=[1,1]
    NP1,NP2=leiji_veh(u)
    leiji_veh1.append(NP1)
    leiji_veh2.append(NP2)
    control_u12.append(u[0])
    control_u21.append(u[1])
print(control_u12)
print(control_u21)
def picture_leijiveh():
    plt.figure(figsize=(6, 4))
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    plt.xlabel('time(2min)')
    plt.ylabel('demand(veh/sec)')
    plt.plot(x, leiji_veh1, label='区域1', linewidth=0.5)
    plt.plot(x, leiji_veh2, label='区域2', linewidth=0.5)
    plt.legend(loc='upper left')
    plt.title('累计车辆数')
    plt.show()

def picture_lowdemand():
        plt.figure(figsize=(6, 4))
        plt.rcParams['font.sans-serif'] = ['SimHei']
        plt.rcParams['axes.unicode_minus'] = False
        plt.xlabel('time(2min)')
        plt.ylabel('demand(veh/sec)')
        plt.plot(x, control_u12, label='u12', linewidth=0.5)
        plt.plot(x, control_u21, label='u21', linewidth=0.5)
        plt.legend(loc='upper left')
        plt.title('低需求')
        plt.show()
picture_lowdemand()
picture_leijiveh()










# print(obj_value)
# print(fit_value)
# print(len(fit_value))
# print(total)
# print(len(fitness))

