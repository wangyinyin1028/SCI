import win32com.client as com
import pandas as pd
import os
import matplotlib.pyplot as plt
import numpy as np
import xlwt

os.chdir('E:\\VISSIM430\\Example\\wyy_excise\\busline_2')
tem = pd.read_table('busline.mes1.txt', encoding='gbk')
# print(tem)
# print(tem[15:].reset_index(drop=True))#截取7行以下的内容
tem = tem[10:].reset_index(drop=True)
tem.columns = ['DATA']
tem1 = pd.DataFrame([var.split(';') for var in tem.DATA])
tem1.columns = ['Measur','from', 'to', 'car','total','bus']
# tem1.drop(['empty'],axis=1,inplace=True)
print(tem1)
df=tem1
df.to_excel('C:\\Users\\Jack Bu\\Desktop\\demo.xls',encoding='utf-8', index=False, header=False)
df1=df.iloc[(df['Measur']=='1').values,[0,1,2,3,4,5]]
df2=df.iloc[(df['Measur']=='2').values,[0,1,2,3,4,5]]
df1.to_excel('C:\\Users\\Jack Bu\\Desktop\\demo1.xls',encoding='utf-8', index=False, header=False)
df2.to_excel('C:\\Users\\Jack Bu\\Desktop\\demo2.xls',encoding='utf-8', index=False, header=False)
# print(df1)
# print(df1.iloc[0:1,3:4])
# print(df1.iloc[0:1,5:6])
# for i in range(len(df1)):
#      # print(i)
#      print(df1.iloc[i:i+1, 3:4])
    # for j in range(len(data)):
    #     pass





def picture():
    plt.figure(figsize=(20,6))
    plt.rcParams['font.sans-serif']=['SimHei']
    plt.rcParams['axes.unicode_minus']=False
    plt.subplot(212)
    plt.ylabel('车辆数',fontsize=15,family= 'Times New Roman')
    plt.xlabel('Time(2 min)',fontsize=15,family= 'Times New Roman')
    plt.xticks(fontsize=15,family= 'Times New Roman')
    plt.yticks(fontsize=15,family= 'Times New Roman')
    plt.title('等待车辆数',fontsize=15,family= 'Times New Roman')
    plt.plot(tem1['to'].astype(float),tem1['car'].astype(float), 'o-', label='car')
    plt.plot(tem1['to'].astype(float),tem1['bus'].astype(float), 'o-', label='bus')
    plt.plot(tem1['to'].astype(float),tem1['total'].astype(float), 'o-', label='total')
    plt.grid(True)
    plt.show()
# print(df.iloc[(df['Measur']=='1').values,[0,2,3,5]])
# print(df.iloc[(df['Measur']=='2').values,[0,2,3,5]])

def picture2():
    plt.figure(figsize=(20,6))
    plt.rcParams['font.sans-serif']=['SimHei']
    plt.rcParams['axes.unicode_minus']=False
    plt.subplot(212)
    plt.ylabel('车辆数',fontsize=15,family= 'Times New Roman')
    plt.xlabel('Time(2 min)',fontsize=15,family= 'Times New Roman')
    plt.xticks(fontsize=15,family= 'Times New Roman')
    plt.yticks(fontsize=15,family= 'Times New Roman')
    plt.title('等待车辆数',fontsize=15,family= 'Times New Roman')
    # plt.plot(df.iloc[(df['Measur']=='2').values,[2]].astype(float),df.iloc[(df['Measur']=='2').values,[3]].astype(float), 'o-', label='car_pass')
    # plt.plot(df.iloc[(df['Measur']=='2').values,[2]].astype(float),df.iloc[(df['Measur']=='2').values,[5]].astype(float), 'o-', label='bus_pass')
    plt.plot(df.iloc[(df['Measur']=='2').values,[2]].astype(float),df.iloc[(df['Measur']=='2').values,[4]].astype(float), 'o-', label='total_pass')
    plt.plot(df.iloc[(df['Measur'] == '1').values, [2]].astype(float),df.iloc[(df['Measur'] == '1').values, [4]].astype(float), 'o-', label='total_wait')
    plt.grid(True)
    plt.legend()
    plt.show()
# picture2()


def write_excel(file_path, datas):
    f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'sheet1',cell_overwrite_ok=True) #创建sheet
    # title = ["from","to","car_wait","total_wait","bus_wait"]  #加入表头
    # # title = ["car_wait", "bus_wait", "total_wait", "car_pass", "bus_pass", "total_pass"]  # 加入表头
    # datas.insert(0, title) #写入表头
    style = xlwt.XFStyle() #创建样式
    align = xlwt.Alignment() #创建对齐方式
    align.horz = 1  #1-->左对齐，2-->居中，3-->右对齐
    style.alignment = align
    #将数据写入第 i 行，第 j 列

    for i in range(len(datas)):
        for j in range(5):
            sheet1.write(i,j,df1.iloc[i:i+1, j:j+1],style=style)
    f.save(file_path) #保存文件
# if __name__ == "__main__":
     # datas = df1
     # write_excel("/Users/Jack Bu/Desktop/demo.xls", datas)