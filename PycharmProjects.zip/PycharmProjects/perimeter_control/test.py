

if __name__ == '__main__':
    import math
    n, m = 4,2
    print(math.factorial(n) // (math.factorial(m) * math.factorial(n - m)))
